<?php

 @$page= $_GET['page'];
		 if($page!="")
		 {
			 switch($page)
			 {
			 case '&ok-login- pqE#f45rg1xd':
			 include('login.php');
			 break;
			 
			 case '&ok-adminsignin-E06vsy4& q6':
			 include('Users/index.php');
			 break;
		
			case '&ok-signup- 3Fg14q5 s8':
			 include('signup.php');
			 break;
			 
			 case 'fogot password-&ok- 7g6Qv&ui':
			 include('fpass.php');
			 break;
			 
			 
			 case '&ok-redir1- 4g6Gs&wi':
			 include('loginconfg.php');
			 break;
			 
            case '&ok-redir2- 7g6r6rf&wiz#':
			 include('logingonfigII.php');
			 break;
            


			 }
		 }
		 else
		 {
		 ?>
    <nav class="header-navbar navbar navbar-with-menu navbar-fixed-top navbar-semi-dark navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav">
            
            <li class="nav-item"><a href="dashboard.php?page=Dashboard" class="navbar-brand nav-link"><img alt="branding logo" src="User/app-assets/images/logo/robust-logo-light.png" data-expand="User/app-assets/images/logo/robust-logo-light.png" data-collapse="User/app-assets/images/logo/robust-logo-small.png" class="brand-logo"></a></li>
            <li class="nav-item hidden-md-up float-xs-right"><a data-toggle="collapse" data-target="#navbar-mobile" class="nav-link open-navbar-container"></a></li>

             
             
         
          </ul>

        </div>
        <div class="navbar-container content container-fluid">
          <div id="navbar-mobile" class="collapse navbar-toggleable-sm">
            <ul class="nav navbar-nav">

              <li class="nav-item hidden-sm-down"><a class="nav-link nav-menu-main menu-toggle hidden-xs"></a></li>
 
</ul>
            <ul class="nav navbar-nav float-xs-right">
              

 <!-- Application notification content-->
              <li class="dropdown dropdown-notification nav-item" data-toggle="tooltip" data-placement="left" title="" data-original-title="You have new Notice">

<a href="User/" class="nav-link nav-link-label"><i class="ficon icon-user"></i><span class="tag  tag-danger tag-default tag-bottom">Admin</span></a>
                
              </li>

<!-- message notification content-->
             
                </div>
      </div>
    </nav>
    
 <?php 
		 }
		  ?>
