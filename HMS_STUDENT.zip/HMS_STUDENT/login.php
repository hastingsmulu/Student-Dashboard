<div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
              <br><br><br><br>
                <section id=" breadcrumb basic-form-layouts">
		

<div class="col-lg-12 ">
     
        <div class="form-outer text-center d-flex align-items-center">
<div class="position" >
<a href="index.php">
<img src="user.svg" alt="logo">
<div class="logo text-uppercase">
<p style="color:gray; ">
<h2>Student Login</h2> 
</p>
</div>
</a>
<br>


<hr><br>
<?php
//Alert msgs i.e. wrong inputs, timeouts,etc.

if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
    			
    			foreach($_SESSION['ERRMSG_ARR'] as $msg) {
    				echo '<p style="color:red;" class="thin text-center">',$msg,'</p>';
    				 
    				}
    			
    			unset($_SESSION['ERRMSG_ARR']);
    			}


?>
<br>
<form action="loginconfg.php" method="post" autocomplete="">
<div class="form-group">
                <label for="login-username" class="label-custom"><i class="icon-user5"></i></label>
                <input class="input"type="text" placeholder="Enter Your Username Here to Login " name="username" required="">
              </div>
<div class="form-group">
                <label for="login-username" class="label-custom"><i class="icon-key2"></i></label>
                <input class="input"type="password" placeholder="Enter Your Password Here to Login " name="pswd" required="">
              </div>

<input type ="hidden" class="hidden" name="oen" value="<?php echo $token;  ?>">
 
<br><button type="submit" name="submit" class="btn btn-success">Login</button>
             
            </form><br>

<a href="fpass.php" class="forgot-pass">Forgot Password?</a><br>
<small>Do not have an account? <a href="fpass.php" class="signup">Signup</a></small><br>
<hr>


          <p style="align: center;">	
          <br>
			<br><br>	
			<br>
<small><a href="User/" class="signup">Login as Admin</a></small><br>
	Designed And Developed by <a href="hastingsmulu.co.ke">Hastings Mulu</a><br>
               &copy; <?php echo date("Y"); ?>  
			</p>
          </div>
        </div>
      </div>
    </div>
						</div>
			
				
			</article>
			<!-- /Article -->

		</div>
	</div>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->



