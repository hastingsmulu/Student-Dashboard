<?php
ob_start();
    	//Start session
    	 session_start();
     
    	//Include database connection details

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','school_db');
// Establish database connection.
try
{
$db = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $x)
{
exit("Error: " . $x->getMessage());
}
    	//Array to store validation errors
    	$errmsg_arr = array();
     
    	//Validation error flag
    	$errflag = false;
     
         
    	//Sanitize the POST values
    	$username = $_POST['username'];
    	$password = $_POST['pswd'];
        $token = md5(uniqid(mt_rand(), true));
	$u='Successfuly';
	$_SESSION['loggedin_time'] = time();  
	$names='Student';
	$daty=date('r');
	$in='Loged in';
    	//Username Input Validations
    	if($username == '') {
    		$errmsg_arr[] = '<img src="User/assets/img/system-error.svg"> Please enter Username ';
    		$errflag = true;
    	}
//Password Input Validations
    	if($password == '') {
    		$errmsg_arr[] = '<img src="User/assets/img/system-error.svg"> Please Enter password ';
    		$errflag = true;
    	}
//If there are input validations, redirect back to the login form
    	if($errflag) {
           
    		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    		session_write_close();
    		header("location: index.php");
    		exit();
    	}

		$sql = "SELECT * FROM students WHERE gyntwfd_username=:uname";
		$pdo_statement = $db->prepare( $sql );
$result = $pdo_statement->execute( array( ':uname'=>	$username,));
	$result = $pdo_statement->fetchAll();
if(!empty($result)) { 

$sql = "SELECT * FROM students WHERE gyntwfd_username=:uname LIMIT 1";
		$pdo_statement = $db->prepare( $sql );
$rows = $pdo_statement->execute( array( ':uname'=>	$username,));
	$rows = $pdo_statement->fetchAll();
	//verifying Password
if(isset($rows[0])){
foreach($rows as $row) {
 if(password_verify($password,$row['xyguf_passwd']))
        {
	 $_SESSION['SESS_MEMBER_ID'] = $row['ID'];
	 $_SESSION['SESS_FNAME']=$row['FullName'];
	  $_SESSION['SESS_SGENDER'] = $row['Gender'];
	 $_SESSION['SESS_SDOB']=$row['DOB'];
	  $_SESSION['SESS_MEMBER_REGNO'] = $row['RegNo'];
	  $_SESSION['SESS_MEMBER_CLASS'] = $row['Class'];
	  $_SESSION['SESS_PASS'] = $token;
	  
$errmsg_arr[] = '<img src="User/assets/img/system-error.svg"> username correct ';
    		$errflag = true;
    		if($errflag) {
           
    		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    		session_write_close();
    		header("location: User/Students/index.php");
    		exit();
    	}
}
$errmsg_arr[] = '<img src="User/assets/img/system-error.svg"> Password incorrect ';
    		$errflag = true;
    		if($errflag) {
           
    		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    		session_write_close();
    		header("location: index.php");
    		exit();
    	}
}}}
unset($db);
   
    ?>



    		
   
