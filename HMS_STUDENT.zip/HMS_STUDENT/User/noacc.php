<?php
session_start();
$msg_arr = array();
$msg_arr[] = 'Please contact your administrator to create an account for you.';
    			$_SESSION['MSG4'] = $msg_arr;
    			header("location: login.php");
  ?>