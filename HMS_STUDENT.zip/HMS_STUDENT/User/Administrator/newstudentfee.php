<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>

 <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">Pay Student Fees Form</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="dashboard.php?page=Students">Students</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">Pay Student Fees</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body">

<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form">Students Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">
						<div class="card-text">
							
						</div>
						<form class="form" method="post" action="misc/newfee.php">
							<div class="form-body">
								<h4 class="form-section"><i class="icon-head"></i> Personal Info</h4><br>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Full Names</label>
											<select name="student" class="form-control">
									 <option value="">Select Students name:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[FullName]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[FullName]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Registration Number</label>
											<select name="studentregno" class="form-control">
									 <option value="">Select Students Registration Number:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[RegNo]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[RegNo]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput3">Class</label>
											<select name="studentclss" class="form-control">
									 <option value="">Select Students Class:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[Class]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[Class]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput4">Session</label>
											<select name="studentclss" class="form-control">
									 <option value="">Select Students Session:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[Session]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[Session]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
								</div>
<br><hr>
								<h4 class="form-section"><i class="icon-clipboard4"></i> Requirements</h4>
<br>
								<div class="form-group">
									<label for="companyName">Paid Amount</label>
									<input type="number" id="Class" class="form-control" placeholder="Paid amount" name="pamount">
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Balance</label>
											<input type="number" id="Class" class="form-control" placeholder="Balance" name="bal">
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Date</label>
											<input type="date" id="Class" class="form-control" placeholder="Date" name="date">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Branch</label>
											<select name="studentclss" class="form-control">
									 <option value="">Select Bank Account Branch:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM branch WHERE status='Active'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[id] == $rsedit[id])
				{
	echo "<option value='$rsdepartment[id]' selected>$rsdepartment[name]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[id]'>$rsdepartment[name]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>

									
								</div>

                                    
								<div class="form-group">
									<label for="projectinput8">Comments</label>
									<textarea id="projectinput8" rows="5" class="form-control" name="comment" placeholder="Comment on student specifics"></textarea>
								</div>
							</div>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>