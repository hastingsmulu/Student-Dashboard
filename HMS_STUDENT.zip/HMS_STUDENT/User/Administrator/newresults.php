<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>

 <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"></h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="dashboard.php?page=Results">Results</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">New Student Result</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body">

<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><i class="icon-man-woman"></i> Student Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">
						<div class="card-text">
							
						</div>
						<form class="form" method="post" action="misc/newresult.php">
							<div class="form-body">
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Name</label>
											<select name="stdntnames" class="form-control">
									 <option value="">Select Student's Name:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[FullName]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[FullName]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Registration Number</label>
											<select name="stdntnames" class="form-control">
									 <option value="">Select Student's Registration Number:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM students WHERE grsxcvg_status='In'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[ID] == $rsedit[ID])
				{
	echo "<option value='$rsdepartment[ID]' selected>$rsdepartment[RegNo]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[ID]'>$rsdepartment[RegNo]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
								</div><br><br>

<p class="text-bold-800">Mandatory Subjecs</p>
<hr>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Mathematics</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Maths Total" name="math">
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">English</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="English Total" name="eng">
										</div>
									</div>
									
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Swahili</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Swahili" name="swa">
										</div>
									</div>
									
								</div><br>
<p class="text-bold-800">Science Subjecs</p>
<hr>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Chemistry</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Chemistry" name="chem">
										</div>
									</div>
									
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Physics</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Physics" name="phy">
										</div>
									</div>
									
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Biology</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Biology" name="bio">
										</div>
									</div>
									
								</div>
<p class="text-bold-800">Humanities Subjecs</p>
<hr>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Business</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Business" name="busi">
										</div>
									</div>
									
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">History</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="History" name="histo">
										</div>
									</div>
									
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Computer Studies</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Computer Studies" name="cstud">
										</div>
									</div>
									
								</div>
<p class="text-bold-800">Religion Subjecs</p>
<hr>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Christian Religion</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Christian Religion" name="crelig">
										</div>
									</div>
									
								

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Islamic religion</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Islamic religion" name="isrelig">
										</div>
									</div>
									
								</div>
<br><br>

<p class="text-bold-800">Total mark, grades and remarks</p><hr>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Total Marks</label>
											<input type="number" id="projectinput3" class="form-control" placeholder="Total Marks" name="totalmarks">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Grade</label>
											<input type="text" id="projectinput3" class="form-control" placeholder="Grade" name="grade">
										</div>
									</div>
									
								
								</div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Remarks</label>
											<textarea  rows="5" class="form-control border-primary" name="Remarks" placeholder="Remarks"></textarea>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Status</label>
											<textarea  rows="5" class="form-control border-primary" name="Status" placeholder="Status"></textarea>
										</div>
									</div>
									
								
								</div>
							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>