<?php 
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','school_db');
// Establish database connection.
try
{
$pdo_conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}



  ?>
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            
         <br>
<?php
include("../includes/msgs.php");

?>

<br><br>
 </div>

 
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">Inbox</a>
                </li>
               
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->


<section id="basic-media-object">
	<div class="row">
		<div class="col-xs-12 mt-1">
			<h4><code><i class="icon-mail6 "></i></code> <kbd> Messages and comments.</h4>
			
			<hr>
		</div>
	</div>
	
	<div class="row match-height ">
	<?php

$pdo_statement = $pdo_conn->prepare("SELECT * FROM messages ORDER BY idm DESC");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
  //showing all data
	if(!empty($result)) { 
		foreach($result as $row) {
	?>
		<div class="col-xl-4 col-lg-12">
			<div class="card  ">
				<form class="form" action="#">
				<div class="card-body collapse in">
					<div class="card-block">
						<div class="media-list ">
							<div class="media ">
								<a class="media-left" href="#">
									</a>

								<div class="list-group">
<ul>
									<li>
<?php 
if ($row["gender"]=='Male'){
echo "<img class='media-object rounded-circle' src='persn.svg' alt='Generic placeholder image' style='width: 64px;height: 64px;' /><br>"; }else
{
echo "<img class='media-object rounded-circle' src='girlstudent.svg' alt='Generic placeholder image' style='width: 64px;height: 64px;' /><br>";
}
?>									

<label for="userinput1">Name:</label>  <?php echo $row["name"]; ?><br>
<label for="userinput1">Email:</label>  <?php echo $row["email"]; ?><br>
<label for="userinput1">Comment:</label>  <?php echo $row["msgs"]; ?></li><br>
<a class="ajax-action-links tag tag-danger" href='delete.php?ID=<?php echo $row['idm']; ?>' data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click to delete message."> <i class="icon-android-delete"></i>   </a>  
<a class="ajax-action-links tag tag-info" href='mailto:<?php echo $row['email']; ?>' data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click to reply massage."> <i class="icon-reply"></i>    </a>
 <?php
if($row["status"]=='New')
{ echo "<a class='ajax-action-links tag tag-danger' href='read mail.php?ID=",$row['idm'],"' data-toggle='tooltip' data-placement='right' title='Mark as Seen'> New</a>";
}
else{
 echo "<span class='ajax-action-links tag tag-warning'data-toggle='tooltip' data-placement='right' title='Seen'> ",$row['time'],"</span>";
}


?> </a><br></ul>
								
<div class="form-group">
											<hr>
										</div></div>

							</div>
							
						</div>
						
					</div>
					
					</div>
					
			</div></div>	
			<?php
		}
	}
	?>
		</div>

</div>
		</div>
</section>

</div>
		</div>
	</div>
