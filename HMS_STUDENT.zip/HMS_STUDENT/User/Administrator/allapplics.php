
<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            
         <br>
<?php 
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
include("../includes/msgs.php")

?>
<br><br>
 </div>

 
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Hostels</a>
                </li>
               
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->

<section id="basic-form-layouts">
	
<div class="row match-height">
		
			<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"> </h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                        <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body collapse in">
                <div class="card-block card-dashboard">
                    <div class="form-group">
                                    <!-- button group -->
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="dashboard.php?page=Add-newroom"><button type="button" class="btn btn-info"><i class="icon-plus"></i> Add New</button></a>
                                       
                                        
                                        
                                    </div>
                                </div>
<p>A list of all Hostels.</p>
                </div>
             <div class="table-responsive">
<div class="table-responsive" style="hight:50%">
              <?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','school_db');
// Establish database connection.
try
{
$pdo_conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}



$pdo_statement = $pdo_conn->prepare("SELECT * FROM hostels ORDER BY id DESC");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
  //showing all data
  ?>
                         <table class="table table-hover" style='width:100%'>
              <thead>
                    <tr>
                  <th><img src=""class="icon-new-tab"></th>
                    
                      <th>Hostel</th>
                     <th>No of Beds</th>
                      <th>Status</th>
                      
</tr>
                  </thead>
                  
                        <tbody id="item">    
  <?php
	if(!empty($result)) { 
		foreach($result as $row) {
	?>
<tr class="table-row">
<td>
<a class="ajax-action-links icon-pencil22" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the Pen icon to edit applicants details" href='misc/edithostel.php?ID=<?php echo $row['id']; ?>'></a>
<a class="ajax-action-links icon-bin" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the bin icon to delete application." href='misc/delethostl.php?ID=<?php echo $row['id']; ?>'></a>
<a class="ajax-action-links icon-printer3" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the print icon, right click on the page and sellect Print then enable Layout to Landscape for printing." href='misc/printhostel.php?ID=<?php echo $row['id']; ?>'></a><br>



</td>

 <td><?php echo $row['name']; ?></td>
	<td><?php echo $row['bednumber']; ?></td>	
		<td><?php echo $row['status']; ?></td>
		
   
   
 <?php
		}
	}
	?>                </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


</div>
</section>


</div>
		</div>


	</div>