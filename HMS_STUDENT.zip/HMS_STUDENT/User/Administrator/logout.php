<?php
/*
Author: hastingsmumo

*/

session_start();
if(session_destroy()) // Destroying All Sessions
{
header("Location: ../../"); // Redirecting To Home Page
}
?>
