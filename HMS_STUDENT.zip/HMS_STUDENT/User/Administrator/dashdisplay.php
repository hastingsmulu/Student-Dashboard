<br><br>
<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>

<div class="app-content content container-fluid">
      <div class="content-wrapper">
        
        <div class="content-body">

<h2 class="content-header-title"> <code><?=$_SESSION['SESS_USERNAME']?></code>, Welcome to your Dashboard!!.</h2>
  
<hr><br>
<!-- Statistics -->
<div class="row">
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-cyan">
            <div class="card-body">
               <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-users2 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Studens</h5>
                        <h5 class="text-bold-400">

<?php
$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM students WHERE grsxcvg_status='In'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?>
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
     </div>
  
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-pink">
            <div class="card-body">
               <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-file-text font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Fees Collection</h5>
                        <h5 class="text-bold-400">
<?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM feescollection";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?>
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-teal">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-library font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Banks</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM branch";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  
<div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-deep-orange">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-user-tie font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Teachers</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM teacher";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-pink">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-books font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Subjects</h5>
                        <h5 class="text-bold-400">
<?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM subjects";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?>
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-cyan">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-home22 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Classes</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM studentclasses ";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-deep-orange">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-insert-template font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Streams</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM stream";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-teal">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-office font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Hostels</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM hostels";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-teal">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-table2 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Timetable</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM timetable";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-deep-orange">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-flag2 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Events</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM events";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-cyan">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-bullhorn font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Notice</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM Notice";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-pink">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                       <i class="icon-trophy2 font-large-2 white"></i></a>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Exam Results</h5>
                        <h5 class="text-bold-400"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM examresults";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div>
<hr><br>
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Recent Fee Collection</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                        <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body collapse in">
                
                <div class="table-responsive">

 <?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','school_db');
// Establish database connection.
try
{
$pdo_conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}



$pdo_statement = $pdo_conn->prepare("SELECT * FROM feescollection ORDER BY id DESC");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
  //showing all data
  ?>
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>Names</th>
                                <th>Amount</th>
                                <th>Balance</th>
                            </tr>
                        </thead>
 <?php
	if(!empty($result)) { 
		foreach($result as $row) {
	?>
                        <tbody>
                            <tr>
                                <th scope="row">

<a class="ajax-action-links icon-pencil22" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the Pen icon to edit applicants details" href=''></a>
<a class="ajax-action-links icon-printer3" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the print icon, right click on the page and sellect Print then enable Layout to Landscape for printing." href=''> </a>
<a class="ajax-action-links icon-bin" data-toggle="tooltip" data-placement="right" title="" data-original-title=" Click the bin icon to delete application." href='delete.php?ID=<?php echo $row['id']; ?>'></a>


</th>
                                <td><?php echo $row['Student']; ?></td>
                                <td><?php echo $row['PaidAmount']; ?></td>
                                <td><?php echo $row['Balance']; ?></td>
                                
                            </tr>
                            <?php
		}
	}
	?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>
<p> <code>Action Tabs.</code> </p>
<hr>
    <div class="row">
        
        <div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-deep-orange media-left media-middle">
                         <p style=" color:white;"> Exams</p>   <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add,View and edit Exam results" href="dashboard.php?page=Exams"> <i class="icon-spell-check font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and edit Exam results</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-teal media-left media-middle">
                           <p style=" color:white;"> Timetable</p><a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add and edit Class Timetable" href="dashboard.php?page=Timetables"> <i class="icon-table2 font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add and edit Class Timetable</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-pink media-left media-middle">
                      <p style=" color:white;"> Teachers</p>    <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to add,edit and view teacher details" href="dashboard.php?page=Teachers"> <i class="icon-user-tie font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,Edit and View Teacher Details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-cyan media-left media-middle">
                         <p style=" color:white;">Parents</p> <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add,View and Delete Parent details" href="dashboard.php?page=Parents"><i class="icon-user font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and Edit Parent details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-pink media-left media-middle">
                         <p style=" color:white;">Exam Results</p> <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add and View Exam Results details" href="dashboard.php?page=Results"><i class="icon-trophy2  font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and Edit Exam Results details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div></div>
<div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-cyan media-left media-middle">
                         <p style=" color:white;">Bank Accounts</p> <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add and View Banks Account details" href="dashboard.php?page=Bank Accounts"><i class="icon-library font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and Edit Bank Accounts details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
</div>
<div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-deep-orange media-left media-middle">
                         <p style=" color:white;">School Events</p> <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add and View Events details" href="dashboard.php?page=Events"><i class="icon-flag2 font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and Edit Events details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
</div></div>
<div class="col-xl-3 col-lg-6 col-xs-12">
            <div class="card">
                <div class="card-body">
                    <div class="media">
                        <div class="p-2 text-xs-center bg-teal media-left media-middle">
                         <p style=" color:white;">Class Streams</p> <a class="ajax-action-links " data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" Click the icon to Add and View Class Streams details" href="dashboard.php?page=Streams"><i class="icon-insert-template font-large-2 white"></i></a>
                        </div>
                        <div class="p-2 media-body">
                            <h5>Add,View and Edit Class Streams details</h5>
                            <h5 class="text-bold-400"></h5>
                        </div>
                    </div>
                </div>
            </div>
</div>
        </div>
    </div></section> 
<hr><br>
 
</div></div></div>

<br><br><br><br><br><br>