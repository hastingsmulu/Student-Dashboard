<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>

 <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">Add New Student Details</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="dashboard.php?page=Students">Students</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">Add New Student</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body">

<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form">Students Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">
						<div class="card-text">
							
						</div>
						<form class="form" method="post" Action="misc/newstudent.php">
							<div class="form-body">
								<h4 class="form-section"><i class="icon-head"></i> Personal Info</h4>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Full Names</label>
											<input type="text" id="projectinput1" class="form-control" placeholder="Full Names" name="fullname">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Gender</label>
											<select id="projectinput5" name="gender" class="form-control">
												<option value="none" selected="" disabled="">Select Gender:</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
												
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput3">Date of Birth</label>
											<input type="date" id="projectinput3" class="form-control" placeholder="Date of Birth" name="dob">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput4">Registration Number</label>
											<input type="text" id="projectinput4" class="form-control" placeholder="Registration Number" name="regno">
										</div>
									</div>
								</div>
<br><hr>
								<h4 class="form-section"><i class="icon-clipboard4"></i> Requirements</h4>

								<div class="form-group">
									<label for="companyName">Class</label>
									<select id="projectinput6" name="class" class="form-control">
												<option value="" selected="" disabled="">Select Class:</option>
<?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM studentclasses WHERE status='Active'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[id] == $rsedit[id])
				{
	echo "<option value='$rsdepartment[id]' selected>$rsdepartment[Name]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[id]'>$rsdepartment[Name]</option>";
				}
				
			}
		  ?></select></div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Stream</label>
											<select id="projectinput6" name="stream" class="form-control">
												<option value="" selected="" disabled="">Select Class Stream:</option>
<?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM stream WHERE status='Active'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[id] == $rsedit[id])
				{
	echo "<option value='$rsdepartment[id]' selected>$rsdepartment[Name]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[id]'>$rsdepartment[Name]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Hostel</label>
											<select id="projectinput6" name="Hostel" class="form-control">
												<option value="" selected="" disabled="">Select Hostel:</option>
												<?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM hostels WHERE status='Available'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[id] == $rsedit[id])
				{
	echo "<option value='$rsdepartment[id]' selected>$rsdepartment[name]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[id]'>$rsdepartment[name]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Date Joined School</label>
											<input type="date" id="doj" class="form-control" placeholder="Date Joined School" name="doj">
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Category</label>
											<input type="text" id="cat" class="form-control" placeholder="Category" name="category">
										</div>
									</div>
								</div>

                                    <div class="row">

                                    <div class="col-md-6">
										<div class="form-group">
											<label for="projectinput6">Parent Name</label>
											<input type="text" id="acayer" class="form-control" placeholder="Academic Year" name="acayear">
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Parent contact No</label>
											<input type="number" id="doj" class="form-control" placeholder="Date Joined School" name="doj">
										</div>
									</div>
								</div>
								<div class="form-group">
									<label for="projectinput8">Comments</label>
									<textarea id="projectinput8" rows="5" class="form-control" name="comment" placeholder="Comment on student specifics"></textarea>
								</div>
							</div>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>