



<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            
         <br>
<?php
include("../includes/msgs.php")

?>
<br><br>
 </div>

 
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="#">My Profile</a>
                </li>
               
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->

<section id="basic-form-layouts">
		<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-colored-form-control">Your Profile Details</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">

						
						<form class="form">
							<div class="form-body">
							
							
								<h4 class="form-section"><i class="icon-eye6"></i> About User</h4>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput1">Names: </label><br>
											<code><?=$_SESSION['SESS_FIRSTNAME']?></code>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput2">Sur Name: </label><br>
											<code><?=$_SESSION['SESS_LASTNAME']?></code>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput3">Username: </label><br>
											<code><?=$_SESSION['SESS_USERNAME']?></code>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput4">Nick Name: </label><br>
											<code><?=$_SESSION['SESS_NICKNAME']?></code>
										</div>
									</div>
								</div>
						<h4 class="form-section"><i class="icon-mail6"></i> Contact Info & Acc type</h4>
                                <div class="row">
									<div class="col-md-6">
								<div class="form-group">
									<label for="userinput5">Email: </label><br>
									<code><?=$_SESSION['SESS_EMAIL']?></code>
								</div></div>
                                <div class="col-md-6">
								<div class="form-group">
									<label for="userinput6">Website: </label><br>
									<code><a href="<?=$_SESSION['SESS_WEB']?>"><?=$_SESSION['SESS_WEB']?></a></code>
								</div></div></div>

								<div class="form-group">
									<label>Contact Number: </label><br>
									<code><?=$_SESSION['SESS_PHONE']?></code>
								</div>

								<div class="form-group">
									<label for="userinput8">Account Type: </label><br>
									<code><?=$_SESSION['SESS_BIOGRAPHY']?></code>
								</div>

							</div>

							
						</form>
</div>
					</div>
				<div   class="card-header">
						<a data-toggle="collapse" data-parent="#accordionWrapa1" href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="card-title lead collapsed">Change your password <i class="icon-arrow-down-b"></i></a>
					</div>
					<div id="accordion2" role="tabpanel" aria-labelledby="heading2" class="card-collapse collapse" aria-expanded="false">
						<div class="card-body">
							<div class="card-block">
                                
<form class="form" action="../includes/seek.php" method="post" onSubmit="return validateform()">    
                                <div class="col-md-6">
                                <div class="form-group">

											<label for="userinput4">Old Password </label>
											<input type="password"  class="form-control border-primary round" required placeholder="Password" name="password">	
                                </div>
								</div>								
<div class="col-md-6">
										<div class="form-group">
											<label for="userinput4">New Password </label>
											<input type="password"  class="form-control border-primary round" required placeholder="Password" name="password">	
                                </div>
								</div>
										<div class="col-md-6">
										<div class="form-group">

											<label for="userinput4">Confirm Password</label>
											<input type="password"  class="form-control border-primary round" required placeholder="Confirm password" name="repass">
										
									</div></div>
<input class="hidden" name="nullval" value="<?=$_SESSION['SESS_MEMBER_ID']?>">
<div class="col-md-6">
                                <div class="form-actions right">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div></div>
						</form>
<script type="application/javascript">
function validateform1()
{
	if(document.frmdoctchangepass.oldpassword.value == "")
	{
		alert("Old password should not be empty..");
		document.frmdoctchangepass.oldpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value == "")
	{
		alert("New Password should not be empty..");
		document.frmdoctchangepass.newpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value.length < 8)
	{
		alert("New Password length should be more than 8 characters...");
		document.frmdoctchangepass.newpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value != document.frmdoctchangepass.password.value )
	{
		alert(" New Password and confirm password should be equal..");
		document.frmdoctchangepass.password.focus();
		return false;
	}
	else
	{
		return true;
	}
}
</script>
								</div>
							</div>
						</div>

			</div>
		</div>

		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-colored-form-control">Change User Profile Details</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">

					
						<form class="form" action="../includes/regeditprof.php" method="post">
							<div class="form-body">
								<h4 class="form-section"><i class="icon-eye6"></i> About User</h4>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput1"> Names </label>
											<input type="text"  class="form-control border-primary" required placeholder="<?=$_SESSION['SESS_FIRSTNAME']?>" name="name">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput2">Sur Name</label>
											<input type="text"  class="form-control border-primary" required placeholder="<?=$_SESSION['SESS_LASTNAME']?> " name="lastname">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput3">Username</label>
											<input type="text"  class="form-control border-primary" required placeholder="<?=$_SESSION['SESS_USERNAME']?>" name="username">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput4">Nick Name</label>
											<input type="text"  class="form-control border-primary" placeholder="<?=$_SESSION['SESS_NICKNAME']?>" name="nickname">
										</div>	</div>
								
					</div>

<br>
								<h4 class="form-section"><i class="icon-mail6"></i> Contact Info & Acc type</h4>

								<div class="form-group">
									<label for="userinput5">Email</label>
									<input class="form-control border-primary" type="email" placeholder="<?=$_SESSION['SESS_EMAIL']?>" name="email">
								</div>

								<div class="form-group">
									<label for="userinput6">Website</label>
									<input class="form-control border-primary" type="url" placeholder="http://<?=$_SESSION['SESS_WEB']?>" name="web">
								</div>

								<div class="form-group">
									<label>Contact Number</label>
									<input class="form-control border-primary" name="tel" type="tel" placeholder="<?=$_SESSION['SESS_PHONE']?>">
								</div>

								<div class="form-group">
									<label for="userinput8">Account Type</label>
									<input class="form-control border-primary" name="class" placeholder="<?=$_SESSION['SESS_BIOGRAPHY']?>">
								</div>

							</div>
<input class="hidden" name="noobsmater" value="<?=$_SESSION['SESS_MEMBER_ID']?>">
							<div class="form-actions right">
								<button type="button" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Cancel
								</button>
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>

					</div>
				</div>
</section>
			</div>
		</div>
	</div>

