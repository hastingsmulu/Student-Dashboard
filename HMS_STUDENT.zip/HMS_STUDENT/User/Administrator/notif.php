<?php 
// DB credentials.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','jdhauler_Contact');
// Establish database connection.
try
{
$pdo_conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}



$pdo_statement = $pdo_conn->prepare("SELECT * FROM grsxcvg_contact ORDER BY id DESC");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
  //showing all data
  ?>