<?php

include("../includes/privatelist.php");
?>
<?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','jdhauler_Contact');
// Establish database connection.
try
{
$pdo_conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}

$pdo_statement = $pdo_conn->prepare("SELECT * FROM grsxcvg_applicantinformation where grsxcvg_ID=" . $_GET["ID"]);
$pdo_statement->execute();
$result = $pdo_statement->fetchAll();
?>
<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Robust admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, robust admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>JD haulersllc Application Form</title>
    <link rel="apple-touch-icon" sizes="60x60" href="../app-assets/images/ico/apple-icon-60.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../app-assets/images/ico/apple-icon-76.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../app-assets/images/ico/apple-icon-120.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../app-assets/images/ico/apple-icon-152.png">
    <link rel="shortcut icon" type="image/x-icon" href="../app-assets/images/ico/favicon.png">
    <link rel="shortcut icon" type="image/png" href="../app-assets/images/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/css/bootstrap.css">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="../app-assets/fonts/icomoon.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/fonts/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/vendors/css/extensions/pace.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/app.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/colors.css">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/core/menu/menu-types/vertical-overlay-menu.css">
    <link rel="stylesheet" type="text/css" href="../app-assets/css/core/colors/palette-gradient.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <!-- END Custom CSS-->
  </head>
  <body data-open="click" data-menu="vertical-menu" data-col="2-columns" class="vertical-layout vertical-menu 2-columns  fixed-navbar">

<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title">Edit Forms</h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="#">Edit Application form</a>
                
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->
<section id="basic-form-layouts">
<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-round-controls">Edit <code> <?php echo $result[0]['grsxcvg_name']; ?></code> Application Form</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">

						<div class="card-text">
							<p><code></code> </p>
						</div>
<form name="frmAdd" action="" method="post"  >
        
									
									<label>Position applying for:</label> <code> <?php echo $result[0]['grsxcvg_positionapplyingfor']; ?></code>
									 <select name="positionapplyingfor">
									 <option value="">Position applying for:</option>
									 <option value="contractor">Contractor</option>
									 <option value="driver">Driver</option>
									 <option value="contractor'sdriver">Contractor's Driver</option>
									  </select><br><br><hr><br>	
									 <p><b>PERSONAL INFORMATION:</b></p>
								<label>Full names:</label> <code> <?php echo $result[0]['grsxcvg_name']; ?></code> 
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_name']; ?>" name="name" size="29" required="">
								
									<label>Phone (+1):</label> <code> <?php echo $result[0]['grsxcvg_phone']; ?></code> 
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_phone']; ?>" name="phone" required="">
								<br>
								<label>Emergency Phone (+1):</label> <code> <?php echo $result[0]['grsxcvg_ephone']; ?></code> 
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_ephone']; ?>" name="ephone" required="">
								<label>Gender:</label> <code> <?php echo $result[0]['grsxcvg_gender']; ?></code> 
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_gender']; ?>" name="gender" required=""><br>
                                <label>Email Address:</label> <code> <?php echo $result[0]['grsxcvg_email']; ?></code> 
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_email']; ?>" name="email" required=""><br>
								<label>Age:</label> <code> <?php echo $result[0]['grsxcvg_age']; ?></code> 
									<input type="number"    placeholder="<?php echo $result[0]['grsxcvg_age']; ?>" name="age">
								<label>Date Of Birth:</label> <code> <?php echo $result[0]['grsxcvg_dob']; ?></code> 
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_dob']; ?>" name="dob" required=""><br>
							<label>Social Securiy #:</label><code> <?php echo $result[0]['grsxcvg_ssh']; ?></code> 
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_ssh']; ?>" name="sshnum" required=""><br><br>
								
									

								   <label>Physical Exam Expiration Date:</label><code> <?php echo $result[0]['grsxcvg_peedate']; ?></code> 
									<input type="text" placeholder="" placeholder="<?php echo $result[0]['grsxcvg_peedate']; ?>"  name="peedate"  required=""><br><br>
									<label>CURRENT & PREVIOUS THREE YEARS ADDRESSES:</label> <br>
									<label>Previous:</label><code> <?php echo $result[0]['grsxcvg_address1']; ?></code> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_address1']; ?>"  name="address1"><br>
								
									<label>Previous:</label><code> <?php echo $result[0]['grsxcvg_address2']; ?></code> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_address2']; ?>" name="address2"><br>
									<label>Current:</label><code> <?php echo $result[0]['grsxcvg_address3']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_address3']; ?>" name="address3"><br>
									<br>
									
									<label>HAVE YOU WORKED FOR THIS COMPANY BEFORE?</label> <code> <?php echo $result[0]['grsxcvg_workedforthiscompanybefore']; ?></code>
									
									 <select name="workedforthiscompanybefore">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select>	<br>
									
									If yes, give dates:<br>
									
									<code> <?php echo $result[0]['grsxcvg_yesfrom']; ?></code> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_yesfrom']; ?>" name="yesfrom">
									
									<code> <?php echo $result[0]['grsxcvg_yesto']; ?></code><input type="text"  placeholder="<?php echo $result[0]['grsxcvg_yesto']; ?>" name="yesto"><br>
									
									<p>Reason for leaving?</p>
									<textarea name="reason" class="form-control"  placeholder="<?php echo $result[0]['grsxcvg_reason']; ?>" rows="09" cols="90"></textarea><br><br>
									<hr>
									<p><b>EDUCATION HISTORY:</b></p>
									<p>Please select the highest grade completed:</p>
									<label>Grade school:</label> <code> <?php echo $result[0]['grsxcvg_schoolgrade']; ?></code>
								
									 <select name="schoolgrade">
									 <option ></option>
 										 <option value="First">1</option>
									    <option value="Second">2</option>
  										 <option value="Third">3</option>
                               <option value="Fourth">4</option>
                               <option value="Fifth">5</option>
                               <option value="Sixth">6</option>
                               <option value="Seventh">7</option>
                               <option value="Eighth">8</option>
                               <option value="Nineth">9</option>
                               <option value="Ten">10</option>
                               <option value="Eleventh">11</option>
                               <option value="Twelveth">12</option>
                               

                               
                            </select>
                               
<br>
                               
                          
									
									<label>College:</label> <code> <?php echo $result[0]['grsxcvg_collegegrade']; ?></code>
									
									<select name="collegegrade">
									<option ></option>
 										 <option value="Yearone">1</option>
									    <option value="Secondyear">2</option>
  										 <option value="Thirdyear">3</option>
                               <option value="Fourthyear">4</option>	
                                </select>
									 <br>
									<label> Post Graduate:</label> <code> <?php echo $result[0]['grsxcvg_postgrade']; ?></code>
									
									<select name="postgrade">
									<option ></option>
 										 <option value="Yearone">1</option>
									    <option value="Secondyear">2</option>
  										 <option value="Thirdyear">3</option>
                               <option value="Fourthyear">4</option>	
                                </select>			<hr>					
									<br><br><br>
									
									
									<p><b>EMPLOYMENT HISTORY:</b></p>
										<p>Give a COMPLETE RECORD of all employment for the past three (3) years, including any unemployment or self
									employment periods, and all commercial driving experience for the past ten (10) years.</p>
									<label>From Month/Year</label>
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_mo_yrfrom1']; ?>"  name="mo_yrfrom1">									
<label>To Month/Year </label> <input type="text" placeholder="To Month/Year" placeholder="<?php echo $result[0]['grsxcvg_mo_yrto1']; ?>"  name="mo_yrto1">									<br>
<label>Present or Last Employer </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_p_lename1']; ?>"  name="p_lename1"size="20">								
<label>Position Held</label><input type="text" placeholder="<?php echo $result[0]['grsxcvg_positionheld1']; ?>"  name="positionheld1">	<br>									
<label>Address </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_empaddress1']; ?>"  name="empaddress1" >
<label>Company phone </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_companytel1']; ?>"  name="companytel1"size="40"><br>									
<label>Reason For Leaving? </label> <textarea name="reasonforleaving1"  class="form-control" placeholder="<?php echo $result[0]['grsxcvg_reasonforleaving1']; ?>"rows="09" cols="90"></textarea>								
									<br>
										Were you subject to the FMCSRs while employed here? <code> <?php echo $result[0]['grsxcvg_fmcsrs1']; ?></code>
									
									<select name="fmcsrs1">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br>
									Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol
									testing requirements of 49 CFR Part 40? <code> <?php echo $result[0]['grsxcvg_cfrpart1']; ?></code>
									
									
									 <select name="cfrpart1">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br><br>
									
                          	<label>From Month/Year</label>
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_mo_yrfrom2']; ?>"  name="mo_yrfrom2">									
<label>To Month/Year </label> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_mo_yrto2']; ?>"  name="mo_yrto2">									<br>	
<label>Present or Last Employer </label> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_p_lename2']; ?>"  name="p_lename2"size="20">								
<label>Position Held </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_positionheld2']; ?>"  name="positionheld2">	<br>									
<label>Address </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_empaddress2']; ?>"  name="empaddress2" >
<label>Company phone </label> <input type="number"  placeholder="<?php echo $result[0]['grsxcvg_companytel2']; ?>"  name="companytel2"size="40"><br>									
<label>Reason For Leaving? </label> <textarea name="reasonforleaving2" class="form-control" placeholder="<?php echo $result[0]['grsxcvg_reasonforleaving2']; ?>"  placeholder="Reason For Leaving?"rows="09" cols="90"></textarea>								
									<br>
										Were you subject to the FMCSRs while employed here?
									 
									 <select name="fmcsrs2">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br>
									Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol
									testing requirements of 49 CFR Part 40?
									
								
									 <select name="cfrpart2">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br><br>
								
									<label>From Month/Year </label> 
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_mo_yrfrom3']; ?>"  name="mo_yrfrom3">									
<label>To Month/Year </label> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_mo_yrto3']; ?>"  name="mo_yrto3">									<br>	
<label>Present or Last Employer </label> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_p_lename3']; ?>"  name="p_lename3"size="20">								
<label>Position Held </label> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_positionheld3']; ?>"  name="positionheld3">		<br>								
<label>Address </label> <input type="text" placeholder="<?php echo $result[0]['grsxcvg_empaddress3']; ?>"  name="empaddress3" >
<label>Company phone </label> <input type="number" placeholder="<?php echo $result[0]['grsxcvg_companytel3']; ?>"  name="companytel3"size="40"><br>									
<label>Reason For Leaving? </label> <textarea name="reasonforleaving3" placeholder="<?php echo $result[0]['grsxcvg_reasonforleaving3']; ?>"  class="form-control" placeholder="Reason For Leaving?"rows="09" cols="90"></textarea>								
									<br>
																	
									
									Were you subject to the FMCSRs while employed here?
									
									 <select name="fmcsrs3">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br>
									Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol
									testing requirements of 49 CFR Part 40?
									
									
									 <select name="cfrpart3">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br><hr>
									  
									<hr>
							
									<p><b>DRIVING EXPERIENCE:</b></p>
									Please don't leave any of the Below Blank: Use N/Y and 0 For Miles for no  Driving Experience.
								<p>(a) Tractor & Semi-trailer</p>
							    
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_frm_a']; ?>"  name="drv_ex_frm_a">									
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_drv_ex_to_a']; ?>"  name="drv_ex_to_a">																	
									<input type="number" placeholder="<?php echo $result[0]['grsxcvg_drv_ex_Miles_a']; ?>"  placeholder="Approximate Miles" name="drv_ex_Miles_a">
                        <p>(b)Tractor & 2 trailers</p>
                           
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_frm_b']; ?>"  name="drv_ex_frm_b">									
									<input type="text" placeholder="<?php echo $result[0]['grsxcvg_drv_ex_to_b']; ?>"  name="drv_ex_to_b">																
									<input type="number"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_Miles_b']; ?>"  name="drv_ex_Miles_b">
								<p>(c)Tractor & 3 trailers</p>
								
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_frm_c']; ?>"  name="drv_ex_frm_c">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_to_c']; ?>"  name="drv_ex_to_c">																	
									<input type="number"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_Miles_c']; ?>"  name="drv_ex_Miles_c">
								<p>(d)Straight Truck</p>
									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_frm_d']; ?>"  name="drv_ex_frm_d">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_to_d']; ?>"  name="drv_ex_to_d">																
									<input type="number"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_Miles_d']; ?>"  name="drv_ex_Miles_d">
								
								<p>Other</p>
									 
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_frm_o']; ?>"  name="drv_ex_frm_o">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_drv_ex_to_o']; ?>"  name="drv_ex_to_o">																
									<input type="number" placeholder="<?php echo $result[0]['grsxcvg_drv_ex_Miles_o']; ?>"  name="drv_ex_Miles_o"><br><br>
									
									List states operated in, for the last five (5) years: <code> <?php echo $result[0]['grsxcvg_liststateopertedin']; ?></code>
									<input type="text" size="70"  placeholder="<?php echo $result[0]['grsxcvg_liststateopertedin']; ?>" class="form-control"name="liststateopertedin"><br>
									List special courses/training completed (PTD/DDC, HAZMAT, ETC): <code> <?php echo $result[0]['grsxcvg_listspecialcourse']; ?></code>
									<input type="text" size="55" class="form-control" placeholder="<?php echo $result[0]['grsxcvg_listspecialcourse']; ?>"  name="listspecialcourse"><br>
									List any Safe Driving Awards you hold and from whom: <code> <?php echo $result[0]['grsxcvg_listsafedrivingaward']; ?></code>
									<input type="text" size="65" class="form-control" placeholder="<?php echo $result[0]['grsxcvg_listsafedrivingaward']; ?>" name="listsafedrivingaward"><br>
									<br>
									<p><b>Accident Record for past three (3) years:</p>
                                     <label>a)</label>
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_accdate_a']; ?>"  name="accdate_a">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_accnatu_a']; ?>" name="accnatu_a">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_locatacci_a']; ?>"  name="locatacci_a">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_numoffatal_a']; ?>"  name="numoffatal_a">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_numoppleinjured_a']; ?>" name="numoppleinjured_a"><br>
									<br>
									<label>b)</label>
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_accdate_b']; ?>" name="accdate_b">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_accnatu_b']; ?>" name="accnatu_b">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_locatacci_b']; ?>" name="locatacci_b">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_numoffatal_b']; ?>" name="numoffatal_b">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_numoppleinjured_b']; ?>" name="numoppleinjured_b"><br>
									</br>
									<label>c)</label>
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_accdate_c']; ?>" name="accdate_c">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_accnatu_c']; ?>" name="accnatu_c">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_locatacci_c']; ?>" name="locatacci_c">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_numoffatal_c']; ?>" name="numoffatal_c">
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_numoppleinjured_c']; ?>" name="numoppleinjured_c"><br>
									
																	
									<br><br>
									
									<p><b>Traffic Convictions and Forfeitures for the last three (3) years (other than parking violations):</p>
									<label>a)</label>
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvdate_a']; ?>" name="tcvdate_a">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvloc_a']; ?>" name="tcvloc_a">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_tcvcharge_a']; ?>" name="tcvcharge_a">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvpenalty_a']; ?>" name="tcvpenalty_a"><br>
										<br>
										
										<label>b)</label>
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvdate_b']; ?>" name="tcvdate_b">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_tcvloc_b']; ?>" name="tcvloc_b">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_tcvcharge_b']; ?>" name="tcvcharge_b">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_tcvpenalty_b']; ?>" name="tcvpenalty_b"><br>
										<br>
										<label>c)</label>
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvdate_c']; ?>" name="tcvdate_c">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvloc_c']; ?>" name="tcvloc_c">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_tcvcharge_c']; ?>" name="tcvcharge_c">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_tcvpenalty_c']; ?>" name="tcvpenalty_c"><br>
										<br>
										
										<p><b>Driver's License (list each driver's license held in the past three(3) years:</b></p>
								<label>a)</label>
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_state_a']; ?>" name="state_a">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_license_a']; ?>" name="license_a">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_type_a']; ?>" name="type_a">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_endorsements_a']; ?>" name="endorsements_a">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_expirationdate_a']; ?>" name="expirationdate_a"><br><br>
									<label>b)</label>
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_state_b']; ?>" name="state_b">									
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_license_b']; ?>" name="license_b">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_type_b']; ?>" name="type_b">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_endorsements_b']; ?>" name="endorsements_b">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_expirationdate_b']; ?>" name="expirationdate_b"><br><br>
									<label>c)</label>
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_state_c']; ?>" name="state_c">									
									<input type="text"  placeholder="<?php echo $result[0]['grsxcvg_license_c']; ?>" name="license_c">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_type_c']; ?>" name="type_c">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_endorsements_c']; ?>" name="endorsements_c">
									<input type="text"   placeholder="<?php echo $result[0]['grsxcvg_expirationdate_c']; ?>" name="expirationdate_c"><br><br>
									
									
                    <p>Have you ever been denied a license, permit or privilege to operate a motor vehicle?</p> <code> <?php echo $result[0]['grsxcvg_deniedalicensetooperate']; ?></code>
                    			
									 <select name="deniedalicensetooperate">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br>
									Has any license, permit or privilege ever been suspended or revoked? <code> <?php echo $result[0]['grsxcvg_licenserevoked']; ?></code>
									
									 <select name="licenserevoked">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select><br> 
									Is there any reason you might be unable to perform the functions of the job for which you have applied (as described in
									the job description)? <code> <?php echo $result[0]['grsxcvg_unabletoperformthefunctionsofthejob']; ?></code>
									
									<select name="unabletoperformthefunctionsofthejob">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select>
									  <br>
									Have you ever been convicted of a felony? <code> <?php echo $result[0]['grsxcvg_convictedofafelony']; ?></code>
									
									<select name="convictedofafelony">
									 <option ></option>
									 <option value="Yes">Yes</option>
									 <option value="No">No</option>
									  </select>
									 <br>
									If the answers to any questions listed above selected -yes-, give details: 
									<textarea name="moredetails" class="form-control"  placeholder="<?php echo $result[0]['grsxcvg_moredetails']; ?>" rows="09" cols="90"></textarea><br> <br>
									<hr>
									<b>JOB REFERENCES:</b>
									
									<p>List three (3) persons for references, other than family members, who have knowledge of your safety habits.</p>
									<label>(a)</label><br>
									<code> <?php echo $result[0]['grsxcvg_name_a']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_name_a']; ?>" name="name_a" required="">								
									<code> <?php echo $result[0]['grsxcvg_address_a']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_address_a']; ?>" name="address_a" required=""><br>
									<code> <?php echo $result[0]['grsxcvg_tel_a']; ?></code> <input type="tel"  placeholder="<?php echo $result[0]['grsxcvg_tel_a']; ?>"  name="tel_a" required=""><br>
									<label>(b)</label><br>
									<code> <?php echo $result[0]['grsxcvg_name_b']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_name_b']; ?>"  name="name_b" required="">									
									<code> <?php echo $result[0]['grsxcvg_address_b']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_address_b']; ?>" name="address_b" required=""><br>
									<code> <?php echo $result[0]['grsxcvg_tel_b']; ?></code> <input type="tel"   placeholder="<?php echo $result[0]['grsxcvg_tel_b']; ?>" name="tel_b" required=""><br>
									<label>(c)</label><br>
									<code> <?php echo $result[0]['grsxcvg_name_c']; ?></code> <input type="text"  placeholder="<?php echo $result[0]['grsxcvg_name_c']; ?>"  name="name_c" required="">									
									<code> <?php echo $result[0]['grsxcvg_address_c']; ?></code> <input type="text"   placeholder="<?php echo $result[0]['grsxcvg_address_c']; ?>" name="address_c" required=""><br>
									<code> <?php echo $result[0]['grsxcvg_tel_c']; ?></code> <input type="tel"  placeholder="<?php echo $result[0]['grsxcvg_tel_c']; ?>" name="tel_c" required=""><br>
									
                                        
											
										<div class="form-actions">
								<button type="button" class="btn btn-warning mr-1">
									<a data-action="close"><i class="icon-cross2"></i> Cancel</a>
								</button>
								<button name="save_record" type="submit"  class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
										
								<hr>
							</div></form>   </div></div></div></div></div> 

<script src="../app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
    <script src="../app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
    <script src="../app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="../app-assets/vendors/js/charts/chart.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="../app-assets/js/core/app-menu.js" type="text/javascript"></script>
    <script src="../app-assets/js/core/app.js" type="text/javascript"></script>
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="../app-assets/js/scripts/pages/dashboard-lite.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>

