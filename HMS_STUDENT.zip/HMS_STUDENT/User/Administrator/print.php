<?php
// version 1.22.4.19
// Include the main TCPDF library (search for installation path).
require_once('offline application form/xapples/tcpdf_include.php');
require_once('offline application form/xapples/db.php');


// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {
	//Page header
	public function Header() {
		// get the current page break margin
		$bMargin = $this->getBreakMargin();
		// get current auto-page-break mode
		$auto_page_break = $this->AutoPageBreak;
		// disable auto-page-break
		$this->SetAutoPageBreak(false, 0);
		// set bacground image
		$img_file = K_PATH_IMAGES.'image_demo.jpg';
		$this->Image($img_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
		// restore auto-page-break status
		$this->SetAutoPageBreak($auto_page_break, $bMargin);
		// set the starting point for the page content
		$this->setPageMark();
	}
}
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', true);



// set document information

$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('JD Haulers LLC');
$pdf->SetTitle('Driver Application Form  ');
$pdf->SetSubject('Driver Application Form');
$pdf->SetKeywords('Driver Application Form, PDF, Driver, Form');

$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' ', PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
$pdf->setFooterData(array(0,64,0), array(0,64,128));

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// IMPORTANT: disable font subsetting to allow users editing the document
$pdf->setFontSubsetting(false);

// set font
$pdf->SetFont('helvetica', '', 10, '', false);

// add a page
$pdf->AddPage();

// get the current page break margin
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->SetAutoPageBreak(false, 0);
// set bacground image
$img_file = K_PATH_IMAGES.'image_demo.jpg';
$pdf->Image($img_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
// restore auto-page-break status
$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
$pdf->setPageMark();


// set default form properties
$pdf->setFormDefaultProp(array('lineWidth'=>1, 'borderStyle'=>'solid', 'fillColor'=>array(255, 255, 200), 'strokeColor'=>array(255, 128, 128)));
$pdf->Ln(10);
$pdf->SetFont('helvetica', '', 18);
$pdf->Cell(0, 5, 'DRIVER APPLICATION FORM', 0, 1, 'C');


$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(35, 5, 'APPLICANT INFORMATION:');
$pdf->Ln(6);


$pdf->Ln(6);

$pdf->SetFont('helvetica', '', 9);

// Date of the day
$pdf->Cell(35, 5, 'Todays Date:');
$pdf->TextField('date', 30, 5, array(), array('v'=>date('Y-m-d'), 'dv'=>date('Y-m-d')));
$pdf->Ln(6);



//Position Applying for:
$pdf->Cell(35, 6, 'Position Applying for:');
$pdf->ComboBox('Position Applying for', 40, 5, array(array('', ''),array('C', 'Contractor'), array('D', 'Driver'), array('CD', 'Contractors Driver')));
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);

// First name
$pdf->Cell(35, 5, 'First name:');
$pdf->TextField('firstname', 50, 5);
$pdf->Ln(6);

// Last name
$pdf->Cell(35, 5, 'Last name:');
$pdf->TextField('lastname', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, 'Phone Number:');
$pdf->TextField('phonenumber', 50, 5);
$pdf->Ln(6);

$pdf->Cell(43, 5, 'Emergency Phone Number:');
$pdf->TextField('emergencyphonenumber', 42, 5);
$pdf->Ln(6);

// Gender
$pdf->Cell(35, 5, 'Gender:');
$pdf->ComboBox('gender', 30, 5, array(array('', ''), array('M', 'Male'), array('F', 'Female')));
$pdf->Ln(6);


$pdf->Cell(35, 5, 'Date of Birth:');
$pdf->TextField('dateofbirth', 50, 5);
$pdf->Ln(6);


$pdf->Cell(35, 5, 'Social Security #:');
$pdf->TextField('socialsecuritynumber', 50, 5);
$pdf->Ln(6);


$pdf->Cell(35, 5, 'Age:');
$pdf->TextField('age', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->SetFont('helvetica', 'I', 9);
$pdf->Cell(35, 5, 'The Age Discrimination of Employment Act of 1967 prohibits discrimination on the basis of age with');
$pdf->Ln(6);
$pdf->Cell(35, 5,'respect to individuals who are at least 40 but less than 70 years of age.');
$pdf->Ln(6);


$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(48, 5, 'Physical Exam Expiration Date:');
$pdf->TextField('physicalexamexpirationdate', 50, 5);
$pdf->Ln(6);


//CURRENT & PREVIOUS THREE YEARS ADDRESSES
$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'CURRENT & PREVIOUS THREE YEARS ADDRESSES');
$pdf->Ln(6);
$pdf->Ln(6);


$pdf->Cell(35, 5, 'Previous:');
$pdf->TextField('Previous11', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, 'Previous:');
$pdf->TextField('Previous22', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, 'Current:');
$pdf->TextField('current', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);


//HAVE YOU WORKED FOR THIS COMPANY BEFORE?

$pdf->Cell(65, 5, 'Have you worked for this company before?:');

$pdf->RadioButton('HAVE YOU WORKED FOR THIS COMPANY BEFORE?', 5, array(), array(), 'Yes');
$pdf->Cell(35, 5, 'Yes');
$pdf->Ln(6);
$pdf->Cell(65, 5, '');
$pdf->RadioButton('HAVE YOU WORKED FOR THIS COMPANY BEFORE?', 5, array(), array(), 'No');
$pdf->Cell(35, 5, 'No');
$pdf->Ln(6);

//If yes, give dates


$pdf->Cell(35, 5, 'If yes, give dates:');
$pdf->Ln(6);
$pdf->Cell(15,5, 'From:');
$pdf->TextField('From55', 50, 5);
$pdf->Cell(10,5, 'To:');
$pdf->TextField('Todd5', 50, 5);
$pdf->Ln(6);

//Reason for leaving?
$pdf->Cell(29, 5, 'Reason for leaving:');
$pdf->TextField('Reasonforleaving112', 130, 18, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none') );
$pdf->Ln(19);
$pdf->Ln(6);






//EDUCATION HISTORY
$pdf->SetFont('helvetica', 'B', 9);
$pdf->Cell(35, 5,'EDUCATION HISTORY:');
$pdf->Ln(6);
 
//Please select the highest grade completed
$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(42, 6, 'Please select the highest grade completed.');
$pdf->Ln(6);
$pdf->Cell(23, 6, 'Grade School:');
$pdf->ComboBox('Grade School', 30, 5, array(array('', ''),array('1', '1'), array('2', '2'), array('3', '3'), array('4', '4'), array('5', '5'), array('6', '6'), array('7', '7'), array('8', '8'), array('9', '9'), array('10', '10'), array('11', '11'), array('12', '12')));
$pdf->Cell(15, 6, 'College:');
$pdf->ComboBox('College', 30, 5, array(array('', ''),array('1', '1'), array('2', '2'), array('3', '3'), 
array('4', '4')));
$pdf->Cell(25, 6, 'Post Graduate:');
$pdf->ComboBox('Post Graduate', 30, 5, array(array('', ''),array('1', '1'), array('2', '2'), array('3', '3'), 
array('4', '4')));
$pdf->Ln(6);
 
 //next page
 
// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 48);

// add a page
$pdf->AddPage();

 //EMPLOYMENT HISTORY
 
$pdf->SetFont('helvetica', 'B', 9);
$pdf->Cell(35, 5,'EMPLOYMENT HISTORY:');
$pdf->Ln(6);


 
$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'Give a COMPLETE RECORD of all employment for the past three (3) years, including any unemployment');
$pdf->Ln(6);
$pdf->Cell(35, 5,'or self employment periods,and all commercial driving experience for the past ten (10) years.');
$pdf->Ln(6);
$pdf->Ln(6);

 
 
$pdf->Cell(29, 5, 'From Month/Year:');
$pdf->TextField('From Month/Year1', 50, 5);
$pdf->Cell(27, 5, 'To Month/Year:');
$pdf->TextField('To Month/Year4', 50, 5);
$pdf->Ln(6);
$pdf->Cell(40, 5, 'Present Or Last Employer:');
$pdf->TextField('Present Or Last Employer5', 50, 5);
$pdf->Cell(22, 5, 'Position Held:');
$pdf->TextField('Position Held7', 50, 5);
$pdf->Ln(6);
$pdf->Cell(17, 5, 'Address:');
$pdf->TextField('Address7', 50, 5);

$pdf->Cell(27, 5, 'Company Phone:');
$pdf->TextField('Company Phone55', 50, 5);
$pdf->Ln(6);
$pdf->Cell(35, 5, 'Reason for leaving:');
$pdf->TextField('Reasonforleaving11', 120, 18, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none') );
$pdf->Ln(19);
$pdf->Ln(6);



$pdf->Cell(117, 5, 'Were you subject to the FMCSRs while employed here? (Answer with Yes or No)');
$pdf->TextField('Were you subject to the FMCSRs while employed here?sfsdf', 50, 5);
$pdf->Ln(6);


$pdf->Cell(35, 5, 'Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol');
$pdf->Ln(6);
$pdf->Cell(95, 5, 'testing requirements of 49 CFR Part 40? (Answer with Yes or No)' );


$pdf->TextField('Was your job designated as a safety-sensitive function in any DOT- 
regulated mode subject to the drug and alcohol testing requirements of 49 CFR Part 40?sfsdf ', 50, 5);

$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(29, 5, 'From Month/Year:');
$pdf->TextField('From Month/Yearccz', 50, 5);
$pdf->Cell(27, 5, 'To Month/Year:');
$pdf->TextField('To Month/Yearasc', 50, 5);
$pdf->Ln(6);
$pdf->Cell(40, 5, 'Present Or Last Employer:');
$pdf->TextField('Present Or Last Employerascaed', 50, 5);
$pdf->Cell(22, 5, 'Position Held:');
$pdf->TextField('Position Held2', 50, 5);
$pdf->Ln(6);
$pdf->Cell(17, 5, 'Address:');
$pdf->TextField('Addresscdcsd', 50, 5);
$pdf->Cell(27, 5, 'Company Phone:');
$pdf->TextField('Company Phonescsvs', 50, 5);
$pdf->Ln(6);
$pdf->Cell(35, 5, 'Reason for leaving:');
$pdf->TextField('Reasonforleavingdfvd', 120, 18, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none'));
$pdf->Ln(19);
 

$pdf->Ln(6);


$pdf->Cell(117, 5, 'Were you subject to the FMCSRs while employed here? (Answer with Yes or No)');
$pdf->TextField('Were you subject to the FMCSRs while employed here?fsdfs', 50, 5 );
$pdf->Ln(6);

$pdf->Cell(35, 5, 'Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol');
$pdf->Ln(6);
$pdf->Cell(95, 5, 'testing requirements of 49 CFR Part 40? (Answer with Yes or No)' );


$pdf->TextField('Was your job designated as a safety-sensitive function in any DOT- 
regulated mode subject to the drug and alcohol testing requirements of 49 CFR Part 40?sfsdsf ', 50, 5);

$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Ln(6);

$pdf->Cell(29, 5, 'From Month/Year:');
$pdf->TextField('From Month/Yearertev', 50, 5);
$pdf->Cell(27, 5, 'To Month/Year:');
$pdf->TextField('To Month/Yearsdfg', 50, 5);
$pdf->Ln(6);
$pdf->Cell(40, 5, 'Present Or Last Employer:');
$pdf->TextField('Present Or Last Employergtrtr', 50, 5);
$pdf->Cell(22, 5, 'Position Held:');
$pdf->TextField('Position Held71', 50, 5);
$pdf->Ln(6);
$pdf->Cell(17, 5, 'Address:');
$pdf->TextField('Addressrtrr', 50, 5);

$pdf->Cell(27, 5, 'Company Phone:');
$pdf->TextField('Company Phonejtykt', 50, 5);
$pdf->Ln(6);
$pdf->Cell(35, 5, 'Reason for leaving:');
$pdf->TextField('Reasonforleavingilio', 120, 18, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none'));
$pdf->Ln(19);
 
$pdf->Cell(35, 5, '');
$pdf->Ln(6);


$pdf->Cell(117, 5, 'Were you subject to the FMCSRs while employed here? (Answer with Yes or No)');
$pdf->TextField('Were you subject to the FMCSRs while employed here?sdfsdfsd', 50, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, 'Was your job designated as a safety-sensitive function in any DOT- regulated mode subject to the drug and alcohol');
$pdf->Ln(6);
$pdf->Cell(95, 5, 'testing requirements of 49 CFR Part 40? (Answer with Yes or No)' );


$pdf->TextField('Was your job designated as a safety-sensitive function in any DOT- 
regulated mode subject to the drug and alcohol testing requirements of 49 CFR Part 40? dcfsdfs', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(27, 5, '(Attach additional sheets for 10-year history, if needed.)'); 




// add a page
$pdf->AddPage();



//DRIVING EXPERIENCE

$pdf->SetFont('helvetica', 'B', 9);
$pdf->Cell(35, 5,'DRIVING EXPERIENCE:');
$pdf->Ln(6);
 


$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5,'(a) Tractor & Semi-trailer .');
$pdf->Ln(6);
 $pdf->Cell(10, 5, 'From:');
$pdf->TextField('Fromjkhkku2', 50, 5);
$pdf->Cell(7, 5, 'To:');
$pdf->TextField('Toooi545', 50, 5);
$pdf->Cell(19, 5, 'Aprox Miles:');
$pdf->TextField('Aprox Miles74857fg', 40, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5,'(b) Tractor & 2 trailers.');
$pdf->Ln(6);
$pdf->Cell(10, 5, 'From:');
$pdf->TextField('Fromsfsf34', 50, 5);
$pdf->Cell(7, 5, 'To:');
$pdf->TextField('Tof34fgrg34', 50, 5);
$pdf->Cell(19, 5, 'Aprox Miles:');
$pdf->TextField('Aprox Milesf34rf34f', 40, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5,'(c) Tractor & 3 trailers.');
$pdf->Ln(6);
$pdf->Cell(10, 5, 'From:');
$pdf->TextField('Fromf34rf3f', 50, 5);
$pdf->Cell(7, 5, 'To:');
$pdf->TextField('Tof34f3434wef', 50, 5);
$pdf->Cell(19, 5, 'Aprox Miles:');
$pdf->TextField('Aprox Milesf34f3', 40, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5,'(d) Straight Truck.');
$pdf->Ln(6);
$pdf->Cell(10, 5, 'From:');
$pdf->TextField('Fromf34f34', 50, 5);
$pdf->Cell(7, 5, 'To:');
$pdf->TextField('Tof34f34', 50, 5);
$pdf->Cell(19, 5, 'Aprox Miles:');
$pdf->TextField('Aprox Milesfgtrg534', 40, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5,'Other.');
$pdf->Ln(6);
$pdf->Cell(10, 5, 'From:');
$pdf->TextField('From4545grgerg', 50, 5);
$pdf->Cell(7, 5, 'To:');
$pdf->TextField('Tofsdfdre43', 50, 5);
$pdf->Cell(19, 5, 'Aprox Miles:');
$pdf->TextField('Aprox Miles34t3gdg', 40, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->Cell(5, 5,'List states operated in, for the last five (5) years:');
$pdf->Ln(6);
$pdf->TextField('List states operated in, for the last five (5) years', 100, 5);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->Cell(5, 5,'List special courses/training completed (PTD/DDC, HAZMAT, ETC).');
$pdf->Ln(6);
$pdf->TextField('List special courses/training completed (PTD/DDC, HAZMAT, ETC).', 100, 5);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->Cell(5, 5,'List any Safe Driving Awards you hold and from whom:');
$pdf->Ln(6);
$pdf->TextField('List any Safe Driving Awards you hold and from whom', 100, 5);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);


$pdf->Cell(35, 5, '');
$pdf->Ln(6);

$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'Accident Record for past three (3) years, please download the form if more space is needed:');
$pdf->Ln(6);



$pdf->Cell(5, 5,'(a)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyyergerge', 30, 5);
$pdf->Cell(28, 5, 'Nature of Accident:');
$pdf->TextField('Nature of Accidentfwewe', 50, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Locatione4gt34', 30, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, '# of Fatalitiess:');
$pdf->TextField('# of Fatalitiessg3r4g3', 30, 5);
$pdf->Cell(29, 5, '# of People Injured:');
$pdf->TextField('# of People Injuredg3rg3g3', 39, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(b)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyy34g34g4', 30, 5);
$pdf->Cell(28, 5, 'Nature of Accident:');
$pdf->TextField('Nature of Accidentg34g34gfdgd', 50, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Location34g34ergergerg', 30, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, '# of Fatalitiess:');
$pdf->TextField('# of Fatalitiess34g34tgertr', 30, 5);
$pdf->Cell(29, 5, '# of People Injured:');
$pdf->TextField('# of People Injuredg34tg34erger', 39, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(c)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyy3ttrgdg34g', 30, 5);
$pdf->Cell(28, 5, 'Nature of Accident:');
$pdf->TextField('Nature of Accident3tgerg3464', 50, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Location12ert34t', 30, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, '# of Fatalitiess:');
$pdf->TextField('# of Fatalitiess235342twet', 30, 5);
$pdf->Cell(29, 5, '# of People Injured:');
$pdf->TextField('# of People Injured23t52wet34t', 39, 5);
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);


$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'Traffic Convictions and Forfeitures for the last three (3) years (other than parking violations):');
$pdf->Ln(6); 




$pdf->Cell(5, 5,'(a)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyyt34t43t', 30, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Location34t2334twertrt', 50, 5);
$pdf->Ln(6);
$pdf->Cell(19, 5, 'Charge:');
$pdf->TextField('Charge344tret5tgt', 50, 5);
$pdf->Cell(15, 5, 'Penalty:');
$pdf->TextField('Penaltyy6hrtg34t', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(b)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyyt34t4ergdrfg', 30, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Locationg34egr34gerg34rg', 50, 5);
$pdf->Ln(6);
$pdf->Cell(19, 5, 'Charge:');
$pdf->TextField('Charge5rtg453g', 50, 5);
$pdf->Cell(15, 5, 'Penalty:');
$pdf->TextField('Penaltyt34erg34ger', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(c)');
$pdf->Cell(18, 5, 'mm/dd/yyy:');
$pdf->TextField('mm/dd/yyy5ytgy56u76i78', 30, 5);
$pdf->Cell(15, 5, 'Location:');
$pdf->TextField('Locationo989ooyuoyu89', 50, 5);
$pdf->Ln(6);
$pdf->Cell(19, 5, 'Charge:');
$pdf->TextField('Charge09piopyuo78', 50, 5);
$pdf->Cell(15, 5, 'Penalty:');
$pdf->TextField('Penalty89089ouioyuty', 50, 5);
$pdf->Ln(6);


$pdf->Cell(35, 5, '');
$pdf->Ln(6);
$pdf->Ln(6);



// add a page
$pdf->AddPage();

$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'Drivers License (list each drivers license held in the past three(3) years: (please download the form if more space is needed):');
$pdf->Ln(6);



$pdf->Cell(5, 5,'(a)');
$pdf->Cell(10, 5, 'State:');
$pdf->TextField('Statep89po7oyuk', 50, 5);
$pdf->Cell(15, 5, 'License:');
$pdf->TextField('Licensek78i78oyuioo78', 50, 5);
$pdf->Cell(10, 5, 'Type:');
$pdf->TextField('Type87o7ouykk78', 40, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, 'Endorsements:');
$pdf->TextField('Endorsements78o78uklu7', 50, 5);
$pdf->Cell(25, 5, 'Expiration Date:');
$pdf->TextField('Expiration Date8io78oyuoyuy7', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(b)');
$pdf->Cell(10, 5, 'State:');
$pdf->TextField('State78oi78ouiyuk', 50, 5);
$pdf->Cell(15, 5, 'License:');
$pdf->TextField('License78i768ioyuiyu', 50, 5);
$pdf->Cell(10, 5, 'Type:');
$pdf->TextField('Type78oo78oyuoy', 40, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, 'Endorsements:');
$pdf->TextField('Endorsementso788o78oyuyu', 50, 5);
$pdf->Cell(25, 5, 'Expiration Date:');
$pdf->TextField('Expiration Datertu56u67iyuiy', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->Cell(5, 5,'(c)');
$pdf->Cell(10, 5, 'State:');
$pdf->TextField('State87oy78oy78oyuoy', 50, 5);
$pdf->Cell(15, 5, 'License:');
$pdf->TextField('License7o6ot6ityiye', 50, 5);
$pdf->Cell(10, 5, 'Type:');
$pdf->TextField('Type45745yutryutrytry', 40, 5);
$pdf->Ln(6);
$pdf->Cell(24, 5, 'Endorsements:');
$pdf->TextField('Endorsementsu56u56uttur', 50, 5);
$pdf->Cell(25, 5, 'Expiration Date:');
$pdf->TextField('Expiration Datetryu56u5urt', 50, 5);
$pdf->Ln(6);
$pdf->Ln(6);





$pdf->Cell(125, 5, 'Have you ever been denied a license, permit or privilege to operate a motor vehicle?');
//$pdf->RadioButton('drink', 5, array('readonly' => 'true'), array(), 'Water');
$pdf->RadioButton('Have you ever been denied a license, permit or privilege to operate a motor vehicle?', 5, array(), array(), 'Yes');
$pdf->Cell(35, 5, 'Yes');
$pdf->Ln(6);
$pdf->Cell(125, 5, '');
$pdf->RadioButton('Have you ever been denied a license, permit or privilege to operate a motor vehicle?', 5, array(), array(), 'No' );
$pdf->Cell(35, 5, 'No');
$pdf->Ln(6);

$pdf->Cell(105, 5, 'Has any license, permit or privilege ever been suspended or revoked?');
//$pdf->RadioButton('drink', 5, array('readonly' => 'true'), array(), 'Water');
$pdf->RadioButton('Has any license, permit or privilege ever been suspended or revoked?', 5, array(), array(), 'Yes');
$pdf->Cell(35, 5, 'Yes');
$pdf->Ln(6);
$pdf->Cell(105, 5, '');
$pdf->RadioButton('Has any license, permit or privilege ever been suspended or revoked?', 5, array(), array(), 'No');
$pdf->Cell(35, 5, 'No');
$pdf->Ln(6);
$pdf->Cell(85, 5, 'Is there any reason you might be unable to perform the functions of the job for which you have applied'); 
$pdf->Ln(6);

$pdf->Cell(58, 5, '(as described in the job description)?');
//$pdf->RadioButton('drink', 5, array('readonly' => 'true'), array(), 'Water');
$pdf->RadioButton('Is there any reason you might be unable to perform the functions of the job for which you have applied (as described in the job description)?', 5, array(), array(), 'Yes');
$pdf->Cell(35, 5, 'Yes');
$pdf->Ln(6);
$pdf->Cell(58, 5, '');
$pdf->RadioButton('Is there any reason you might be unable to perform the functions of the job for which you have applied (as described in the job description)?', 5, array(), array(), 'No');
$pdf->Cell(35, 5, 'No');
$pdf->Ln(6);

$pdf->Cell(65, 5, 'Have you ever been convicted of a felony?');
//$pdf->RadioButton('drink', 5, array('readonly' => 'true'), array(), 'Water');
$pdf->RadioButton('Have you ever been convicted of a felony?', 5, array(), array(), 'Yes');
$pdf->Cell(35, 5, 'Yes');
$pdf->Ln(6);
$pdf->Cell(65, 5, '');
$pdf->RadioButton('Have you ever been convicted of a felony?', 5, array(), array(), 'No');
$pdf->Cell(35, 5, 'No');
$pdf->Ln(6);

$pdf->Cell(35, 5, 'If the answers to any questions listed above selected - yes -, give details:');
$pdf->Ln(6);
$pdf->TextField('answers', 160, 28, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none'));
$pdf->Ln(19);
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);$pdf->Ln(6);

//JOB REFERENCES
$pdf->SetFont('helvetica', 'B', 9);
$pdf->Cell(35, 5,'JOB REFERENCES:');
$pdf->Ln(6);
 

$pdf->SetFont('helvetica', '', 9);
$pdf->Cell(35, 5, 'List three (3) persons for references, other than family members, who have knowledge of your safety habits.');
$pdf->Ln(6);

$pdf->Cell(35, 5, '');
$pdf->Ln(6);


$pdf->Cell(5, 5,'(a)');
$pdf->Cell(18, 5, 'Full Names:');
$pdf->TextField('fullnames(a)', 50, 5);
$pdf->Cell(15, 5, 'Address:');
$pdf->TextField('address(a)', 40, 5);
$pdf->Cell(12, 5, 'Phone:');
$pdf->TextField('phone(a)', 40, 5);
$pdf->Ln(6);

$pdf->Cell(5, 5,'(b)');
$pdf->Cell(18, 5, 'Full Names:');
$pdf->TextField('fullnames(b)', 50, 5);
$pdf->Cell(15, 5, 'Address:');
$pdf->TextField('address(b)', 40, 5);
$pdf->Cell(12, 5, 'Phone:');
$pdf->TextField('phone(b)', 40, 5);
$pdf->Ln(6);

$pdf->Cell(5, 5,'(c)');
$pdf->Cell(18, 5, 'Full Names:');
$pdf->TextField('fullnames(c)', 50, 5);
$pdf->Cell(15, 5, 'Address:');
$pdf->TextField('address(c)', 40, 5);
$pdf->Cell(12, 5, 'Phone:');
$pdf->TextField('phone(c)', 40, 5);
$pdf->Ln(6);
$pdf->Ln(6);
$pdf->CheckBox('t&c', 5, false, array(), array(), 'Ok');
$html = <<<EOD
I have read the <a href="../../page_terms.php">Terms and Conditions</a>
EOD;
$pdf->writeHTML($html, true, 0, true, 0);



$pdf->Cell(35, 5, 'Remarks: (For office use only)');
$pdf->Ln(6);
$pdf->TextField('Remarks', 160, 28, array('multiline'=>true, 'lineWidth'=>0, 'borderStyle'=>'none'));
$pdf->Ln(19);
$pdf->Ln(6);
$pdf->Ln(6);





// Button to validate and print
$pdf->Button('print', 30, 10, 'Print', 'Print()', array('lineWidth'=>2, 'borderStyle'=>'beveled', 'fillColor'=>array(128, 196, 255), 'strokeColor'=>array(64, 64, 64)));

$pdf->Button('submit', 30, 10, 'Submit', array('S'=>'SubmitForm', 'F'=>'http://localhost/pages/Register.php', 'Flags'=>array('ExportFormat')), array('lineWidth'=>2, 'borderStyle'=>'beveled', 'fillColor'=>array(128, 196, 255), 'strokeColor'=>array(64, 64, 64)));



// Form validation functions
$js = <<<EOD
function CheckField(name,message) {
	var f = getField(name);
	if(f.value == '') {
	    app.alert(message);
	    f.setFocus();
	    return false;
	}
	return true;
}
function Print() {
	if(!CheckField('firstname','Please enter First name')) {return;}
	if(!CheckField('lastname','Please enter Last name')) {return;}
	if(!CheckField('phonenumber','Please enter Phone Number')) {return;}
	if(!CheckField('gender','Please enter Gender')) {return;}
	if(!CheckField('socialsecuritynumber','Please enter Social Security #')) {return;}
	if(!CheckField('physicalexamexpirationdate','Please enter Physical Exam Expiration Date')) {return;}
	if(!CheckField('current','Please enter Current Address')) {return;}
	if(!CheckField('fullnames(a)','Please enter Full Names references')) {return;}
	if(!CheckField('address(a)',' Please enter Address references')) {return;}
	if(!CheckField('phone(a)','Please enter Phone references')) {return;}
	if(!CheckField('fullnames(b)','Please enter Full Names references')) {return;}
	if(!CheckField('address(b)','Please enter Address references')) {return;}
	if(!CheckField('phone(b)','Please enter Phone references')) {return;}
	if(!CheckField('fullnames(c)','Please enter Full Names references')) {return;}
	if(!CheckField('address(c)','Please enter Address references')) {return;}
	if(!CheckField('phone(c)','Please enter Phone references')) {return;}
	if(!CheckField('t&c','Please enter Terms and Conditions')) {return;}
	print();
}
EOD;

// Add Javascript code
$pdf->IncludeJS($js);

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('driver application form.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
