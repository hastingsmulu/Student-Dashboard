<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_USERNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>

 <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            <h2 class="content-header-title"></h2>
          </div>
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php?page=Dashboard">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="dashboard.php?page=Teachers">Teachers</a>
                </li>
                <li class="breadcrumb-item active"><a href="#">Add new Teacher Details</a>
                </li>
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body">

<section id="basic-form-layouts">
	<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-form"><i class="icon-user-tie"></i> Teacher Info</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">
						<div class="card-text">
							
						</div>
						<form class="form" method="" action="misc/teachernew.php">
							<div class="form-body">
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Name</label>
											<input type="text" id="projectinput3" class="form-control" placeholder="Name" name="name">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput5">Main Subject</label>
											<select name="subject" class="form-control">
									 <option value="">Select Main Subject:</option>
									  <?php
// Create connection

require_once "con.php";
		  	$sqldepartment= "SELECT * FROM subjects WHERE status='Active'";
			$qsqldepartment = mysqli_query($con,$sqldepartment);
			while($rsdepartment=mysqli_fetch_array($qsqldepartment))
			{
				if($rsdepartment[id] == $rsedit[id])
				{
	echo "<option value='$rsdepartment[id]' selected>$rsdepartment[name]</option>";
				}
				else
				{
  echo "<option value='$rsdepartment[id]'>$rsdepartment[name]</option>";
				}
				
			}
		  ?></select>
										</div>
									</div></div>
<div class="row">
<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Other Subject</label>
											<input type="text" id="projectinput3" class="form-control" placeholder="Other Subject" name="Other_Subject">
										</div>
									</div>
								
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Duties</label>
											<input type="text" id="projectinput3" class="form-control" placeholder="Duties" name="duties">
										</div>
									</div></div>
<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="projectinput1">Status</label>
											<select id="projectinput5" name="status" class="form-control">
												<option value="none" selected="" disabled="">Select Teacher Available or Absent </option>
												<option value="Available">Available</option>
												<option value="Absent">Absent</option>
												
											</select>
										</div>
									</div>
								</div>
								

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</section>
<!-- // Basic form layout section end -->
        </div>
      </div>
    </div>