<br><br>
<?php
 if(!isset($_SESSION['SESS_PASS'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_MEMBER_ID'])) {
    		header("location: ../login.php");
    		exit();
    	}
if(!isset($_SESSION['SESS_FNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
?>
<script>

document.addEventListener("DOMContentLoaded", () => {
 function counter(id, start, end, duration) {
  let obj = document.getElementById(id),
   current = start,
   range = end - start,
   increment = end > start ? 1 : 0,
   step = Math.abs(Math.floor(duration / range)),
   timer = setInterval(() => {
    current += increment;
    obj.textContent = current;
    if (current == end) {
     clearInterval(timer);
    }
   }, step);
 }
 counter("count1", 0, <?php
$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

    
$sql = "SELECT * FROM students WHERE grsxcvg_status='In'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
mysqli_close($con);
?>, 3000);

 counter("count2", 20000, <?php

echo $_SESSION['SESS_SPAID'];
?>, 100);

counter("count3",0,<?php



echo $_SESSION['SESS_SCLASS'];
?>,2800);

counter("count4",0,<?php



echo $_SESSION['SESS_SSUB'];
?>,2800);

counter("count5",0,<?php



echo $_SESSION['SESS_SHOST'];
?>,2800);
});

</script>

<div class="app-content content container-fluid">
      <div class="content-wrapper">
        
        <div class="content-body">

<h2 class="content-header-title"> <code><?=$_SESSION['SESS_FNAME']?></code>, Welcome to your Dashboard!!.</h2>
  
<hr><br>
<!-- Statistics -->
<div class="row">
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-cyan">
            <div class="card-body">
               <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-user font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Admision No:</h5>
                        <h5 class="text-bold-400 font-medium-5">

<?=$_SESSION['SESS_MEMBER_REGNO']?>
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
     </div>
  
    <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-pink">
            <div class="card-body">
               <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-money2 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Fees Paid</h5>
                        <h5 class="text-bold-400">KSh: <span id="count2" class="font-medium-5">
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-teal">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-android-calendar font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Date Of Birth</h5>
                        <h5 class="text-bold-400 font-medium-5"><?=  $_SESSION['SESS_SDOB'];?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>  
<div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-deep-orange">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-home22 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Class</h5>
                        <h5 class="text-bold-400 font-medium-5"><span id="count3" class="font-medium-5"></span> <?=$_SESSION['SESS_STREAM']?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-amber">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-calendar5 font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Academic Year</h5>
                        <h5 class="text-bold-400 font-medium-5"><?= $_SESSION['SESS_SAD'];
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-pink">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-books font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Subjects</h5>
                        <h5 class="text-bold-400">
<span id="count4" class="font-medium-5"></span>
</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  
  <div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-teal">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-office font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Hostels</h5>
                        <h5 class="text-bold-400 font-medium-5"><?= $_SESSION['SESS_SHOSTN'];
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 
<div class="col-xl-3 col-lg-6 col-xs-12">
        <div class="card bg-green">
            <div class="card-body">
                <div class="card-block">
                <div class="media">
                    <div class="media-left media-middle">
                        <i class="icon-android-calendar font-large-2 white"></i>
                    </div>
                    <div class="media-body white text-xs-right">
                        <h5>Date Joined</h5>
                        <h5 class="text-bold-400 font-medium-5"><?= $_SESSION['SESS_SDOJ'];
?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div></div>
<hr><br>
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Fee Collection</h4>
                <a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
                        <li><a data-action="reload"><i class="icon-reload"></i></a></li>
                        <li><a data-action="expand"><i class="icon-expand2"></i></a></li>
                        <li><a data-action="close"><i class="icon-cross2"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-body collapse in">
                
                <div class="table-responsive">

 <?php 



$pdo_statement = $pdo_conn->prepare("SELECT * FROM feescollection ORDER BY id DESC");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
  //showing all data
  ?>
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Names</th>
                                <th>Amount</th>
                                <th>Balance</th>
                            </tr>
                        </thead>
 <?php
	if(!empty($result)) { 
		foreach($result as $row) {
	?>
                        <tbody>
                            <tr>
                                
                                <td><?php echo $row['Student']; ?></td>
                                <td><?php echo $row['PaidAmount']; ?></td>
                                <td><?php echo $row['Balance']; ?></td>
                                
                            </tr>
                            <?php
		}
	}
	?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>

        </div>
    </div></section> 
<hr><br>
 
</div></div></div>

<br><br><br><br><br><br>
