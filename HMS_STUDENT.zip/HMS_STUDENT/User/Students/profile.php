



<div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-xs-12 mb-1">
            
         <br>
<?php
include("../includes/msgs.php");
include("studentlog.php");
?>
<br><br>
 </div>

 
          <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-xs-12">
            <div class="breadcrumb-wrapper col-xs-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a>
                </li>
                <li class="breadcrumb-item"><a href="#">My Profile</a>
                </li>
               
              </ol>
            </div>
          </div>
        </div>
        <div class="content-body"><!-- Basic form layout section start -->

<section id="basic-form-layouts">
		<div class="row match-height">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4 class="card-title" id="basic-layout-colored-form-control">Your Profile Details</h4>
					<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
					<div class="heading-elements">
						<ul class="list-inline mb-0">
							<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
							<li><a data-action="reload"><i class="icon-reload"></i></a></li>
							<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
							<li><a data-action="close"><i class="icon-cross2"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="card-body collapse in">
					<div class="card-block">

						<?php 
if ($_SESSION['SESS_SGEN']=='Male'){
echo "<img class='media-object rounded-circle' src='persn.svg' alt='Generic placeholder image' style='width: 64px;height: 64px;' /><br>"; }else
{
echo "<img class='media-object rounded-circle' src='girlstudent.svg' alt='Generic placeholder image' style='width: 64px;height: 64px;' /><br>";
}
?>	
					<br><form class="form">
							<div class="form-body">
							
							
								<h4 class="form-section"><i class="icon-user4"> </i> About User</h4>
								<div class="row"><hr>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput1">Names: </label><br>
											<code><?=$_SESSION['SESS_FNAME']?></code>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput2">Parents Name: </label><br>
											<code><?=$_SESSION['SESS_SPNM']?></code>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput3">Registration Number: </label><br>
											<code><?=$_SESSION['SESS_MEMBER_REGNO']?></code>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="userinput4">Class: </label><br>
											<code><?=$_SESSION['SESS_STREAM']?> <?=$_SESSION['SESS_MEMBER_CLASS']?></code>
										</div>
									</div>
								</div><hr><br><br>
						<h4 class="form-section"><i class="icon-information-circled"> </i>Gurdian Contact Info </h4>
                                <div class="row"><hr><br>
									<div class="col-md-6">
								<div class="form-group">
									<label for="userinput5">Parent Contacts: </label><br>
									<code><?=$_SESSION['SESS_SPCNT']?></code>
								</div></div>
                                <div class="col-md-6">
								<div class="form-group">
									<label for="userinput6"> </label><br>
									<code></code>
								</div></div></div>

								

							
						</form>
</div>
					</div>
				<div   class="card-header">
						<a data-toggle="collapse" data-parent="#accordionWrapa1" href="#accordion2" aria-expanded="false" aria-controls="accordion2" class="card-title lead collapsed">Change your password <i class="icon-arrow-down-b"></i></a>
					</div>
					<div id="accordion2" role="tabpanel" aria-labelledby="heading2" class="card-collapse collapse" aria-expanded="false">
						<div class="card-body">
							<div class="card-block">
                                
<form class="form" action="seek.php" method="post" onSubmit="return validateform()">    
                                <div class="col-md-6">
                                <div class="form-group">

											<label for="userinput4">Old Password </label>
											<input type="password"  class="form-control border-primary round" required placeholder="Password" name="o-password">	
                                </div>
								</div>								
<div class="col-md-6">
										<div class="form-group">
											<label for="userinput4">New Password </label>
											<input type="password"  class="form-control border-primary round" required placeholder="New Password" name="new-password">	
                                </div>
								</div>
										<div class="col-md-6">
										<div class="form-group">

											<label for="userinput4">Confirm Password</label>
											<input type="password"  class="form-control border-primary round" required placeholder="Confirm password" name="repass">
										
									</div></div>
<input class="hidden" name="nullval" value="<?=$_SESSION['SESS_MEMBER_ID']?>">
<div class="col-md-6">
                                <div class="form-actions right">
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div></div>
						</form>
<script type="application/javascript">
function validateform1()
{
	if(document.frmdoctchangepass.oldpassword.value == "")
	{
		alert("Old password should not be empty..");
		document.frmdoctchangepass.oldpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value == "")
	{
		alert("New Password should not be empty..");
		document.frmdoctchangepass.newpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value.length < 8)
	{
		alert("New Password length should be more than 8 characters...");
		document.frmdoctchangepass.newpassword.focus();
		return false;
	}
	else if(document.frmdoctchangepass.newpassword.value != document.frmdoctchangepass.password.value )
	{
		alert(" New Password and confirm password should be equal..");
		document.frmdoctchangepass.password.focus();
		return false;
	}
	else
	{
		return true;
	}
}
</script>
								</div>
							</div>
						</div>

			</div>
		</div>

		
</section>
			</div>
		</div>
	</div>

