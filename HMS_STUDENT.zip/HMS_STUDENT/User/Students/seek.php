<?php
ob_start();
    	//Start session
    	 session_start();
     
    	//Include database connection details

          require_once("../includes/db.php");
    	//Array to store validation errors
    	$msg_arr = array();
     
    	//Validation error flag
    	$msgflag = false;
     
        
     
    	//Sanitize the POST values
       $id=$_POST['nullval']; 
       $opswd=$_POST['o-password']; 
$b = $_POST['new-password'];
$c = $_POST['repass'];
$hashed_password = password_hash($c, PASSWORD_DEFAULT);
if($b!=$c){
$msg_arr[] = '<img src="../assets/img/system-error.svg"> New Password Did Not Match with Retyped Password. Try Again ';
    			$msgflag = true;
    			if($msgflag) {
                      
    				$_SESSION['ERRMSG_ARRED'] = $msg_arr;
    				session_write_close();
    				header("location: index.php?page=My-Profile");
    				exit();
    			}}
    	$password=password_hash($_POST['repass'],PASSWORD_DEFAULT);


    	//Input Validations
    	$sql = "SELECT * FROM students WHERE ID=:uname";
	$pdo_statement = $pdo_conn->prepare( $sql );
	$rows = $pdo_statement->execute( array( ':uname'=>	$id,));
	$rows = $pdo_statement->fetchAll();
//verifying Password
if(isset($rows[0])){
foreach($rows as $row) {
 if(password_verify($_POST['o-password'], $row['xyguf_passwd']))
        {
        
      $sql = "UPDATE students 
        SET xyguf_passwd=?
		WHERE ID=?";
$q = $db->prepare($sql);
$q->execute(array($hashed_password,$id));
  
      
    		    $msg_arr[] = '<img src="../assets/img/icon_success.svg"> You have successifuly updated your password, please login. ';
    			$msgflag = true;
    			if($msgflag) {
                      
    				$_SESSION['ERRMSG_ARR'] = $msg_arr;
    				session_write_close();
    			header("location: index.php?page=My-Profile");
                exit();
    			}
    		}}
    		
{

//failed
    			$msg_arr[] = '<img src="../assets/img/system-error.svg"> Something went wrong, Try Again. ';
    			$msgflag = true;
    			if($msgflag) {
                      
    				$_SESSION['ERRMSG_ARRED'] = $msg_arr;
    				session_write_close();
    				header("location: index.php?page=My-Profile");
    				exit();
    			}
}


//failed
    			
}






    		die("Query failed");
    $conn->close();
    	ob_end_flush();
    ?>
