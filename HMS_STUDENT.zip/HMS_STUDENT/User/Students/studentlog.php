<?php

if(!isset($_SESSION['SESS_FNAME'])){
    		header("location: ../login.php");
    		exit();
    	}
    	
$host = 'localhost';
$database = 'school_db';
$user = 'root';
$password = '';
$dsn = "mysql:host=$host;dbname=$database;charset=utf8";
$pdo_conn = new PDO($dsn, $user, $password);

$id = $_SESSION['SESS_FNAME'];

	$result = $pdo_conn->prepare("SELECT * FROM feescollection WHERE Student= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){

    $_SESSION['SESS_S_ID'] = $row['id'];
    $_SESSION['SESS_SNAME'] = $row['Student'];
    $_SESSION['SESS_SRN'] = $row['RegNo'];
    $_SESSION['SESS_SCLASS'] =  $row['Class']; 
    $_SESSION['SESS_SSESS'] = $row['Session'];
    $_SESSION['SESS_SPAID'] = $row['PaidAmount'];
    $_SESSION['SESS_SDATE'] = $row['Date'];
    $_SESSION['SESS_SREMAK'] = $row['Remarks'];

}
$result = $pdo_conn->prepare("SELECT * FROM students WHERE FullName= :memid");
	$result->bindParam(':memid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){

	 $_SESSION['SESS_STREAM']=$row['Stream'];
	 $_SESSION['SESS_SDOJ']=$row['DOJ'];
	    $_SESSION['SESS_SAD'] = $row['AcademicYear'];
	    $_SESSION['SESS_SGEN'] = $row['Gender'];
	  $_SESSION['SESS_SHOST'] = $row['Hostel'];
	  $_SESSION['SESS_SSUB'] = $row['no_subject'];
	 $_SESSION['SESS_SDOB']=$row['DOB'];
	 $_SESSION['SESS_SPNM']=$row['Parent'];
	 $_SESSION['SESS_SPCNT']=$row['Parent_contacts'];

}
$result = $pdo_conn->prepare("SELECT * FROM hostels WHERE id= :memid");
	$result->bindParam(':memid', $_SESSION['SESS_SHOST']);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){

	$_SESSION['SESS_SHOSTN'] = $row['name'];
	 
	  

}

unset($db);

?>
