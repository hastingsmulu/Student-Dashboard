 <?php

    session_start();		
    ?>

<!-- navbar-fixed-top-->
    <nav class="header-navbar navbar navbar-with-menu navbar-fixed-top navbar-semi-dark navbar-shadow">
      <div class="navbar-wrapper">
        <div class="navbar-header">
          <ul class="nav navbar-nav">
            <li class="nav-item mobile-menu hidden-md-up float-xs-left"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5 font-large-1"></i></a></li>
            <li class="nav-item"><a href="dashboard.php?page=Dashboard" class="navbar-brand nav-link"><img alt="branding logo" src="../app-assets/images/logo/robust-logo-light.png" data-expand="../app-assets/images/logo/robust-logo-light.png" data-collapse="../app-assets/images/logo/robust-logo-small.png" class="brand-logo"></a></li>
            <li class="nav-item hidden-md-up float-xs-right"><a data-toggle="collapse" data-target="#navbar-mobile" class="nav-link open-navbar-container"><i class="icon-ellipsis pe-2x icon-icon-rotate-right-right"></i></a></li>

             
             
         
          </ul>

        </div>
        <div class="navbar-container content container-fluid">
          <div id="navbar-mobile" class="collapse navbar-toggleable-sm">
            <ul class="nav navbar-nav">

              <li class="nav-item hidden-sm-down"><a class="nav-link nav-menu-main menu-toggle hidden-xs"><i class="icon-menu5">         </i></a></li>
 
</ul>
            <ul class="nav navbar-nav float-xs-right">
              

 <!-- Application notification content-->
              <li class="dropdown dropdown-notification nav-item" data-toggle="tooltip" data-placement="left" title="" data-original-title="You have <?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM Notice WHERE status='New'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?> new Notice">

<a href="dashboard.php?page=Notices"  class="nav-link nav-link-label"><i class="ficon icon-bullhorn"></i><span class="tag tag-pill tag-default tag-danger tag-default tag-up"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM Notice WHERE status='New'";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></span></a>
                
              </li>

<!-- message notification content-->
              <li class="dropdown dropdown-notification nav-item" data-toggle="tooltip" data-placement="left" title="" data-original-title="You have <?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM events";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?> new events"><a href="index.php?page=My-Inbox" class="nav-link nav-link-label"><i class="ficon icon-flag2"></i><span class="tag tag-pill tag-default tag-info tag-default tag-up"><?php


$con=mysqli_connect("localhost","root","","school_db");

// Check connection
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$sql = "SELECT * FROM events";
	$qsql = mysqli_query($con,$sql);
	echo mysqli_num_rows($qsql);
?></span></a>
                
              </li>
 <!-- User Dropdown Content-->
 <ul class="nav navbar-nav float-xs-right">
 <li class="dropdown dropdown-user nav-item"> <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-link dropdown-user-link"> <i class="icon-head"  data-toggle="tooltip" data-placement="left" title="" data-original-title="Loged in as <?=$_SESSION['SESS_FNAME']?>"></i><span  > <?=$_SESSION['SESS_MEMBER_REGNO']?> </span></a>
                <div class="dropdown-menu dropdown-menu-right">
<a href="index.php?page=My-Profile" class="dropdown-item" data-toggle="tooltip" data-placement="left" title="" data-original-title="My Profile "> <i class="icon-head" ></i><code><?=$_SESSION['SESS_FNAME']?></code></a>
                  <div class="dropdown-divider"></div><a href="logout.php" class="dropdown-item"><i class="icon-power3"></i>Logout</a>
                </div>
              </li>
            </ul>


        </div>
      </div>
    </nav>

<div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
      <!-- main menu header-->
      <div class="main-menu-header">
<form class="form">
<fieldset class="form-group position-relative">

        <input type="text" placeholder="Search" class="menu-search form-control round " id="iconLeft" /> <div class="form-control-position">

<i class="icon-search font-medium-3"></i>     </div>
              </fieldset>

         
      </div>
      <!-- / main menu header-->
      <!-- main menu content-->
      <div class="main-menu-content">
        <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
          <li class=" nav-item"><a href="index.php?page=Dashboard"><i class="icon-home3" href="index.php?page=Dashboard"></i><span data-i18n="nav.dash.main" class="menu-title">Dashboard</span></a>
        </li>
         
 <li class=" nav-item"><a href="index.php?page=Notices"><i class="icon-bullhorn" href="index.php?page=Notices"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Notices</span></a>
            
          </li> 
           



<li class=" nav-item"><a href="index.php?page=Documentation"><i class="icon-ios-paper" href="index.php?page=Documentation"></i><span data-i18n="nav.page_layouts.main" class="menu-title">Documentation</span></a>
            
          </li> 
           </div>
      <!-- /main menu content-->
      <!-- main menu footer-->
      <!-- include includes/menu-footer-->
      <!-- main menu footer-->
    </div>
