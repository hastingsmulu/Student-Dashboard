<?php
session_start();
$msg_arr = array();
$msg_arr[] = 'Please contact your administrator to reset your account.';
    			$_SESSION['ERRMSG_ARR'] = $msg_arr;
    			header("location: login.php?page=&ok-login- pqE#f45rg1xd");
  ?>