<?php

header("location:index.php?page=&ok-signin- E0Zr3&K5d q6");
?>