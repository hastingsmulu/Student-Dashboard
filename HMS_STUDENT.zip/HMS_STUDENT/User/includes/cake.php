<?php
header ("location : data/cookies.php")
?>