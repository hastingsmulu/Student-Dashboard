<?php
ob_start();
    	//Start session
    	session_start();
     
    	//Include database connection details
     	
include('db.php');

    	//Array to store validation errors
    	$errmsg_arr = array();
      

    //User Class Flag
    $classflag = false;
     
    	//Validation error flag
    	$errflag = false;
     
    	
     
        	//Sanitize the POST values
        

        $username=($_POST['username']);
    	$password=($_POST['passwrd']);
        $token = md5(uniqid(mt_rand(), true));
    	//Input Validations
    	if($password == '') {
    		$errmsg_arr[] = '<img src="assets/img/system-error.svg"> Incorrect Username or Password. Try Again.';
    		$errflag = true;
    	}
        
       	 
       

    //If there are input validations, redirect back to the login form
    	    if($errflag) {
    		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    		session_write_close();
    		header("location: ../signin.php");
    		exit();
    	}

          

 $sql = "SELECT * FROM users WHERE group_username=:uname";
		$pdo_statement = $pdo_conn->prepare( $sql );
$rows = $pdo_statement->execute( array( ':uname'=>	$username,));
	$rows = $pdo_statement->fetchAll();


//verifying Password
if(isset($rows[0])){
foreach($rows as $row) {
 if(password_verify($_POST['passwrd'], $row['grsxcvg_passsword']))
        {
    			//Login Successful
    			session_regenerate_id();
    			
           /* Store there credentials */
    		    $_SESSION['SESS_MEMBER_ID'] = $row['id'];
            $_SESSION['SESS_FIRSTNAME'] = $row['grsxcvg_firstname'];
            $_SESSION['SESS_LASTNAME'] = $row['grsxcvg_lastname'];
            $_SESSION['SESS_NICKNAME'] = $row['grsxcvg_nickname'];
    		    $_SESSION['SESS_USERNAME'] = $row['group_username'];
    		    $_SESSION['SESS_EMAIL'] = $row['grsxcvg_email'];
    		    $_SESSION['SESS_PASS'] =  $token;
            $_SESSION['SESS_PHONE'] = $row['grsxcvg_phone'];
            $_SESSION['SESS_WEB'] = $row['grsxcvg_website'];
            $_SESSION['SESS_BIOGRAPHY'] = $row['gvsax_usertype'];
    			session_write_close();
    			header("location: ../Administrator/dashboard.php?page=Dashboard");
    			exit();
    			}
    		
}
    		}
//Login Successful
else {
                



//Login failed
              

    			
    			$errmsg_arr[] = ' <img src="assets/img/system-error.svg"> Incorrect Username or Password, try again.';
    			$errflag = true;
    			if($errflag) {
    				$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    				session_write_close();
    				header("location: ../index.php?page=&ok-signin- E0Zr3&K5d q6");
    				exit();
    			}
}
    		$errmsg_arr[] = ' <img src="assets/img/system-error.svg"> Incorrect Username or Password, try again.';
    			$errflag = true;
    			if($errflag) {
    				$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
    				session_write_close();
    				header("location: ../index.php?page=&ok-signin- E0Zr3&K5d q6");
    				exit();
    			}
    ?>
