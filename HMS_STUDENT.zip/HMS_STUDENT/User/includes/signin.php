
<?php

//Start session
    	session_start();
    	$token =$_SESSION['token'] = md5(uniqid(mt_rand(), true));
     ?>   	
    	



<div class="login-page">

				

		<div class="login-page">

			
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				
			<p>	
		
			</p>
	

<div class="page login-page">
     
        <div class="form-outer text-center d-flex align-items-center">
<div class="position" >
<a href="login.php"> <img src="assets/img/homebank.png" alt="logo" style="align: center; ">
 <div class="logo text-uppercase"></div></a><br>
<h2>School Management System</h2>
<span style="color:gray;"></span>
<hr><br>

<h2 class="icon-user-check" style="color:#1B5E20;">  </h2>
<h2 ><span style="background-color:#fffca;color:gray;"> <?=$_SESSION['SESS_FIRSTNAME']?> <?=$_SESSION['SESS_LASTNAME'] ?>  </span> </h2>
<h4><span style="background-color:#fff;color:darkgray;">  <?=$_SESSION['SESS_EMAIL']?>  </span></h4>
<?php
    	//Alert msgs i.e. wrong inputs, timeouts,etc.
		if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
    			
    			foreach($_SESSION['ERRMSG_ARR'] as $msg) {
    				echo '<p style="color:red;" class="thin text-center">',$msg,'</p>'; 
    				}
    			
    			unset($_SESSION['ERRMSG_ARR']);
    			}


?>
<form action="includes/logingonfigII.php"  method="post" autocomplete="on">
<div class="form-group">
                <label for="login-password" class="label-custom"></label>
                <input class="input" type="password" placeholder="Enter Password Here to login" name="passwrd" required=""> 
              </div>
              <input type ="hidden" class="hidden" name="coffee" value="<?php echo $token;  ?>">
<input type ="hidden" class="hidden" name="username" value="<?=$_SESSION['SESS_USERNAME']?>">
<input type ="hidden" class="hidden" name="class" value="<?=$_SESSION['SESS_CLASS']?>">
<br><button type="submit" name="" class="btn btn-success">Sign in</button>
</form>
<br>
<a href="fpass.php" class="forgot-pass">Forgot Password?</a><br>
<small>Do not have an account? <a href="fpass.php" class="signup">Signup</a></small><br>
<hr>


          <p style="align: center;">	
          <br>
			
	
               Designed by <a href="hastingsmulu.co.ke">Hastings Mulu</a><br>
              &copy; <?php echo date("Y"); ?> 
			</p>
          </div>
        </div>
      </div>
    </div>
						</div>
			
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
		




