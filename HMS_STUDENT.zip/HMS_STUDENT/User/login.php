<?php
    	//Start session
    	session_start();	
    		
    	//Unset the variables stored in session
    	unset($_SESSION['SESS_MEMBER_ID']);
    	unset($_SESSION['SESS_FIRSTNAME']);
    	unset($_SESSION['SESS_LASTNAME']);
        unset( $_SESSION['SESS_NICKNAME']);
    	unset( $_SESSION['SESS_USERNAME']);
    	unset($_SESSION['SESS_EMAIL']);
        unset($_SESSION['SESS_PASS']);
    	unset( $_SESSION['SESS_PHONE']);
        unset( $_SESSION['SESS_WEB']);
        unset( $_SESSION['SESS_BIOGRAPHY']);
         unset( $_SESSION['SESS_TOKEN']);
    session_destroy();
?>

<?php

include_once("main.php");
include_once("includes/capoe.php");
?>
	<?php

 @$page= $_GET['page'];
		 if($page!="")
		 {
			 switch($page)
			 {
			 case '&ok-login- pqE#f45rg1xd':
			 include('login.php');
			 break;
			 
			 case '&ok-signin- E0Zr3&K5d q6':
			 include('signin.php');
			 break;
		
			case '&ok-signup- 3Fg14q5 s8':
			 include('signup.php');
			 break;
			 
			 case 'fogot password-&ok- 7g6Qv&ui':
			 include('fpass.php');
			 break;
			 
			 
			 case '&ok-redir1- 4g6Gs&wi':
			 include('includes/loginconfg.php');
			 break;
			 
            case '&ok-redir2- 7g6r6rf&wiz#':
			 include('includes/logingonfigII.php');
			 break;
            


			 }
		 }
		 else
		 {
		 ?>
 <?php 
		 }
		  ?><!-- /container -->
		</body>
	</html>

